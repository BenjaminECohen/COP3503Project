#include "Map.h"

Map::Map(std::string mapFile) {
	mapString = "";
}

Map::Map() {
	mapString = "";
}
void Map::Render() {

	for (int i = 0; i < blockArray.size(); i++) {
		if (blockArray[i].exists) {
			blockArray[i].Render();
		}
	}

}

void Map::Update(){

}

void Map::LoadMap(std::string mapFile) {

	std::ifstream input;
	std::string mapString;
	input.open(mapFile);
	std::array<std::string, 12> map;
	int count = 0;

	while (!input.eof()) {
		input >> map[count];
		count++;
	}
	count = 0;

	for (int i = 0; i < blockArray.size(); i++) {
		blockArray[i].exists = false;
	}

	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 64; j++) {
			if (map[i].at(j) == '1') {
				blockArray[count] = Block(j * 64, ((11 - i) * 64), "Assets/Art/box.png", 1);
				count++;
				cout << "1";
			}
			else if (map[i].at(j) == '2') {
				blockArray[count] = Block(j * 64, ((11 - i) * 64), "Assets/Art/scithersword.png", 2);
				count++;
				cout << "2";
			}
			else if (map[i].at(j) == '3') {
				blockArray[count] = Block(j * 64, ((11 - i) * 64), "Assets/Art/snowflake.png", 3);
				count++;
				cout << "3";
			}
			else {
				cout << "0";
			}
		}
		cout << endl;
	}
}