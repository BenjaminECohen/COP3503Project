#include "Player.h"
#include "Map.h"
#include "GameState.h"
using namespace std;




int main() {

	Engine engine;
	engine.Init("Test");
	Player player;
	Map map;


	
	
	
	while (true) {

		switch (GameState::getGameState()) {
		case 1:
			map.LoadMap("Assets/Maps/map1.txt");
			player = Player(0, 100, map.blockArray);
			break;
		case 2:
			map.LoadMap("Assets/Maps/map2.txt");
			player = Player(0, 100, map.blockArray);
			break;
		case 3:

			break;
		default:
			break;
		}

		GameState::restartStates = false;
		GameState::changeStates = false;

		while (true) {
			engine.Update();
			player.Update();

			

			engine.BeginRender();

			map.Render();
			player.Render();

			engine.EndRender();

			if (GameState::changeStates) {
				GameState::setGameState(GameState::getGameState() + 1);
				break;
			}

			if (GameState::restartStates) {
				break;
			}
		}
	}

	return 0;
}