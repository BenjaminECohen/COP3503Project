#include "Block.h"

int Block::BLOCK_HEIGHT = 64;
int Block::BLOCK_WIDTH = 64;

Block::Block(int xPos, int yPos, std::string blockSprite, int blockType) {
	this->xPos = xPos;
	this->yPos = yPos;
	Block::blockSprite = Sprite(blockSprite, xPos, yPos);
	this->blockSprite.SetScaleTo(1);
	exists = 1;
	this->blockType = blockType;
}

int Block::getBlockType(){
	return blockType;
}

int Block::getXPos() {
	return xPos;
}

int Block::getYPos() {
	return yPos;
}

Block::Block() {
	exists = 0;
}

void Block::Render() {
	blockSprite.Render(BLOCK_WIDTH, BLOCK_HEIGHT);
}

void Block::Update() {

}