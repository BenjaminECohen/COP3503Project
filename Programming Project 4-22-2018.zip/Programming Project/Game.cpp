#include "Player.h"
#include "Map.h"
#include "GameState.h"
#include "Background.h"
using namespace std;




int main() {

	Engine engine;
	engine.Init("Test");
	Player player;
	Map map;
	Background background;



	
	
	
	while (true) {

		switch (GameState::getGameState()) {
		case 1:
			map.LoadMap("Assets/Maps/map1.txt");
			player = Player(0, 100, map.blockArray, map.basicEnemyArray);
			map.setProjectileArray(player.projectileArray);
			background = Background("Assets/Art/Desert1.png");
			break;
		case 2:
			map.LoadMap("Assets/Maps/map2.txt");
			player = Player(0, 100, map.blockArray, map.basicEnemyArray);
			map.setProjectileArray(player.projectileArray);
			background = Background("Assets/Art/Desert2.png");
			break;
		case 3:
			map.LoadMap("Assets/Maps/map3.txt");
			player = Player(0, 100, map.blockArray, map.basicEnemyArray);
			map.setProjectileArray(player.projectileArray);
			background = Background("Assets/Art/Desert3.png");
			break;
		case 4:
			map.LoadMap("Assets/Maps/map4.txt");
			player = Player(1000, 100, map.blockArray, map.basicEnemyArray);
			map.setProjectileArray(player.projectileArray);
			background = Background("Assets/Art/full_background.png");
			break;
		default:
			break;
		}

		GameState::restartStates = false;
		GameState::changeStates = false;

		while (true) {
			engine.Update();
			player.Update();
			map.Update();
			background.Update();
			map.setProjectileArray(player.projectileArray);
			player.setBasicEnemyArray(map.basicEnemyArray);
			player.setChaseEnemyArray(map.chaseEnemyArray);
			player.setTurretEnemyArray(map.turretEnemyArray);
			player.setBoss(map.bigBoss);
			map.setPlayerPos(player.getXPos(),  player.getYPos());

			engine.BeginRender();

			background.Render();
			map.Render();
			player.Render();

			engine.EndRender();

			if (GameState::changeStates) {
				GameState::setGameState(GameState::getGameState() + 1);
				break;
			}

			if (GameState::restartStates) {
				break;
			}
		}
	}

	return 0;
}