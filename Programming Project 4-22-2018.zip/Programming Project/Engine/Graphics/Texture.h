#pragma once

#include "GLFW\glfw3.h"
#include "simple-opengl-image-library-master\src\SOIL.h"

#include <iostream>
#include <string>
using namespace std;

class Texture {

public:
	Texture();
	Texture(int _id);
	Texture(string path);

	int GetID();
	int GetWidth();
	int GetHeight();

private:
	bool GetTextureParams();
	int id;
	int width;
	int height;
};