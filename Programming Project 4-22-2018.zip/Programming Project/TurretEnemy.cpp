#include "TurretEnemy.h"

TurretEnemy::TurretEnemy() {
	currentXPos = 0;
	currentYPos = 0;
	initialXPos = 0;
	initialYPos = 0;
	xVel = 0;
	yVel = 0;
	health = 400;
	attackDamage = 1;
	turretSprite = Sprite("Assets/Art/FaceMonster2.png", initialXPos, initialYPos);
	turretSprite.SetScaleTo(1);
	exists = false;
}

TurretEnemy::TurretEnemy(float _xPos, float _yPos, std::array<Block, 100> blockArray, std::array<Projectile, 5> playerProjectileArray) {
	currentXPos = _xPos;
	currentYPos = _yPos;
	initialXPos = _xPos;
	initialYPos = _yPos;
	xVel = 0;
	yVel = 0;
	health = 400;
	attackDamage = 1;
	turretSprite = Sprite("Assets/Art/turret2L_Cropped.png", initialXPos, initialYPos);
	turretSprite.SetScaleTo(1);
	this->blockArray = blockArray;
	this->playerProjectileArray = playerProjectileArray;
	exists = true;
}

void TurretEnemy::Update(float playerXPos, float playerYPos) {
	//Set a path
	if (abs(playerXPos - currentXPos) < 750) {
		shoot(playerXPos, playerYPos);
	}
	for (int i = 0; i < projectileArray.size(); i++) {
		if (projectileArray[i].exists) {
			projectileArray[i].Update();
		}
	}
	turretSprite.SetPosTo(currentXPos, currentYPos);
	currentYPos += yVel;
	checkCollisions();
	checkDeath();
}

void TurretEnemy::setPlayerProjectileArray(std::array<Projectile, 5> playerProjectileArray) {
	this->playerProjectileArray = playerProjectileArray;
}


void TurretEnemy::checkDeath() {
	if (health <= 0) {
		exists = false;
	}
}

void TurretEnemy::Render() {
	turretSprite.Render();
	for (int i = 0; i < projectileArray.size(); i++) {
		if (projectileArray[i].exists) {
			projectileArray[i].Render();
		}
	}
}

void TurretEnemy::shoot(float playerXPos, float playerYPos) {
	for (int i = 0; i < projectileArray.size(); i++) {
		if (!projectileArray[i].exists) {
			projectileArray[i] = Projectile(currentXPos + turretSprite.GetWidth() / 2,
				currentYPos + turretSprite.GetHeight() / 2,
				playerXPos,
				playerYPos,
				.5,
				"Assets/Art/snowflake.png", 30, 30);
			break;
		}
	}
}

void TurretEnemy::checkCollisions() {
	if (currentYPos < 1) {
		yVel = 0;
		hasJump = true;
	}
	else {		//Makes the enemy fall down when he isn't on the ground (gives the game a kind of gravity).

		if (yVel <= -1.5) {
			yVel = -1.5;
		}
		else {
			yVel -= .003;
		}
	}
	for (int i = 0; i < blockArray.size(); i++) {	//This makes it so that the enemy doesn't go through any of the boxes.

		if (currentYPos + turretSprite.GetHeight() > blockArray[i].getYPos() && currentYPos < blockArray[i].getYPos() + 64) {
			if (currentXPos > blockArray[i].getXPos() + 32) {
				if ((currentYPos + turretSprite.GetHeight()) >(blockArray[i].getYPos())) {
					if ((currentXPos + xVel) <= (blockArray[i].getXPos() + 64)) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos() + 64);
					}
				}
			}
			else {
				if (currentYPos < blockArray[i].getYPos() + 64) {
					if ((currentXPos + xVel + turretSprite.GetWidth()) >(blockArray[i].getXPos())) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos()) - turretSprite.GetWidth();
					}
				}
			}
		}

		if (currentXPos + turretSprite.GetWidth() > blockArray[i].getXPos() && currentXPos < blockArray[i].getXPos() + 64) {
			if (currentYPos > blockArray[i].getYPos() + 32) {
				if ((currentXPos + turretSprite.GetWidth()) > (blockArray[i].getXPos())) {
					if ((currentYPos + yVel) <= (blockArray[i].getYPos() + 64)) {
						yVel = 0;
						hasJump = true;
						currentYPos = (blockArray[i].getYPos() + 64);
					}
				}
			}
			else {
				if (currentXPos < blockArray[i].getXPos() + 64) {
					if ((currentYPos + yVel + turretSprite.GetHeight()) >(blockArray[i].getYPos())) {
						yVel = 0;
						currentYPos = (blockArray[i].getYPos()) - turretSprite.GetHeight();
					}
				}
			}
		}

		for (int i = 0; i < playerProjectileArray.size(); i++) {

			if (playerProjectileArray[i].exists) {
				if (currentYPos + turretSprite.GetHeight() > playerProjectileArray[i].getYPos() && currentYPos < playerProjectileArray[i].getYPos() + playerProjectileArray[i].getHeight()) {
					if (currentXPos > playerProjectileArray[i].getXPos() + playerProjectileArray[i].getWidth() / 2) {
						if ((currentYPos + turretSprite.GetHeight()) > (playerProjectileArray[i].getYPos())) {
							if ((currentXPos + xVel) <= (playerProjectileArray[i].getXPos() + playerProjectileArray[i].getWidth())) {
								playerProjectileArray[i].exists = false;
								setHealth(getHealth() - 1);
								//cout << "hit" << endl;
							}
						}
					}
					else {
						if (currentYPos < playerProjectileArray[i].getYPos() + playerProjectileArray[i].getHeight()) {
							if ((currentXPos + xVel + turretSprite.GetWidth()) >(playerProjectileArray[i].getXPos())) {
								playerProjectileArray[i].exists = false;
								setHealth(getHealth() - 1);
								//cout << "hit" << endl;
							}
						}
					}
				}

				if (currentXPos + turretSprite.GetWidth() > playerProjectileArray[i].getXPos() && currentXPos < playerProjectileArray[i].getXPos() + playerProjectileArray[i].getWidth()) {
					if (currentYPos > playerProjectileArray[i].getYPos() + playerProjectileArray[i].getWidth() / 2) {
						if ((currentXPos + turretSprite.GetWidth()) > (playerProjectileArray[i].getXPos())) {
							if ((currentYPos + yVel) <= (playerProjectileArray[i].getYPos() + playerProjectileArray[i].getHeight())) {
								playerProjectileArray[i].exists = false;
								setHealth(getHealth() - 1);
								//cout << "hit" << endl;
							}
						}
					}
					else {
						if (currentXPos < playerProjectileArray[i].getXPos() + playerProjectileArray[i].getWidth()) {
							if ((currentYPos + yVel + turretSprite.GetHeight()) >(playerProjectileArray[i].getYPos())) {
								playerProjectileArray[i].exists = false;
								setHealth(getHealth() - 1);
								//cout << "hit" << endl;
							}
						}
					}
				}
			}
		}

		if (!blockArray[i].exists) {
			break;
		}
	}
}

void TurretEnemy::setHealth(int _health) {
	health = _health;
}

int TurretEnemy::getHealth() {
	return health;
}

int TurretEnemy::getAttackDamage() {
	return attackDamage;
}

float TurretEnemy::getXPos() {
	return currentXPos;
}

float TurretEnemy::getYPos() {
	return currentYPos;
}

int TurretEnemy::getHeight() {
	return turretSprite.GetHeight();
}

int TurretEnemy::getWidth() {
	return turretSprite.GetWidth();
}

Projectile TurretEnemy::getProjectile(int i) {
	return projectileArray[i];
}