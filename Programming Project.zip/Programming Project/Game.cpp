#include <iostream>
#include "Engine\Engine.h"
#include "Engine\Graphics\Sprite.h"
#include "Engine\Input\Mouse.h"
#include "Engine\Input\Keyboard.h"

using namespace std;

int main() {

	Engine engine;

	engine.Init("Test");

	Sprite testSprite = Sprite("Assets/Art/box.png", 0, 0);
	Sprite secondSprite = Sprite("Assets/Art/scithersword.png", 500, 500);
	testSprite.SetScaleTo(1);
	secondSprite.SetScaleTo(1);

	while (true) {

		engine.Update();
		testSprite.Update();
		secondSprite.Update();


		if (Mouse::ButtonDown(GLFW_MOUSE_BUTTON_LEFT)) {
			testSprite.SetRotBy(10);
		}
		if (Mouse::ButtonUp(GLFW_MOUSE_BUTTON_RIGHT)) {
			testSprite.SetRotBy(-10);
		}
		if (Mouse::Button(GLFW_MOUSE_BUTTON_RIGHT)) {
			testSprite.SetRotBy(-.01);
		}

	
		if (Keyboard::Key(GLFW_KEY_W)) {
			testSprite.MoveUp();
		}
		if (Keyboard::Key(GLFW_KEY_A)) {
			testSprite.MoveLeft();
		}
		if (Keyboard::Key(GLFW_KEY_S)) {
			testSprite.MoveDown();
		}
		if (Keyboard::Key(GLFW_KEY_D)) {
			testSprite.MoveRight();
		}


		if (Keyboard::Key(GLFW_KEY_UP)) {
			secondSprite.MoveUp();
		}
		if (Keyboard::Key(GLFW_KEY_LEFT)) {
			secondSprite.MoveLeft();
		}
		if (Keyboard::Key(GLFW_KEY_DOWN)) {
			secondSprite.MoveDown();
		}
		if (Keyboard::Key(GLFW_KEY_RIGHT)) {
			secondSprite.MoveRight();
		}

		engine.BeginRender();
		testSprite.Render();
		secondSprite.Render();
		engine.EndRender();
	}

	return 0;
}