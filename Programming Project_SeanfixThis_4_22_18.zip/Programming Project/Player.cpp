#include "Player.h"

//Delete this constructor?
Player::Player() {
	xPos = 0;
	yPos = 0;
	xVel = 0;
	yVel = 0;
	Camera::setXCoord(0);
	Camera::setYCoord(0);
	health = 3;
	initialHealth = 3;
	attackDamage = 1;
	playerSprite = Sprite("Assets/Art/bad-character.png", xPos, yPos);
	playerSprite.SetScaleTo(1);
	playerSpriteFlip = Sprite("Assets/Art/bad-character_flip.png", xPos, yPos);
	playerSpriteFlip.SetScaleTo(1);
}

Player::Player(float xPos, float yPos, std::array<Block, 768> blockArray) {
	this->xPos = xPos;
	this->yPos = yPos;
	xVel = 0;
	yVel = 0;
	Camera::setXCoord(0);
	Camera::setYCoord(0);
	health = 3;
	initialHealth = 3;
	attackDamage = 1;
	playerSprite = Sprite("Assets/Art/bad-character.png", xPos, yPos);
	playerSprite.SetScaleTo(1);
	playerSpriteFlip = Sprite("Assets/Art/bad-character_flip.png", xPos, yPos);
	playerSpriteFlip.SetScaleTo(1);
	this->blockArray = blockArray;
	//All this GL stuff makes it so that if the player dies and the map restarts, the camera goes back to the beginning of the level.
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(Camera::getXCoord(), Camera::getYCoord() + Engine::SCREEN_WIDTH, 0, Engine::SCREEN_HEIGHT, -10, 10);
	glMatrixMode(GL_MODELVIEW);
}

void Player::Render() {
	if (xVel < 0)
	{
		playerSpriteFlip.Render();
	}
	else
	{
		playerSprite.Render();
	}
	
	for (int i = 0; i < projectileArray.size(); i++) {
		if (projectileArray[i].exists) {
			projectileArray[i].Render();
		}
	}
	
}

void Player::moveCamera() {
	if (xPos < 3755) {
		if (xPos - Camera::getXCoord() > Engine::SCREEN_WIDTH*(0.66)) {
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			glOrtho(xPos - Engine::SCREEN_WIDTH*(0.66), xPos + Engine::SCREEN_WIDTH*(0.33), 0, Engine::SCREEN_HEIGHT, -10, 10);
			glMatrixMode(GL_MODELVIEW);
			Camera::setXCoord(xPos - Engine::SCREEN_WIDTH*(.66));
		}
		if (xPos - Camera::getXCoord() < Engine::SCREEN_WIDTH*(0.33) && xPos > Engine::SCREEN_WIDTH*(0.33)) {
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			glOrtho(xPos - Engine::SCREEN_WIDTH*(0.33), xPos + Engine::SCREEN_WIDTH*(0.66), 0, Engine::SCREEN_HEIGHT, -10, 10);
			glMatrixMode(GL_MODELVIEW);
			Camera::setXCoord(xPos - Engine::SCREEN_WIDTH*(.33));
		}
	}
}

int Player::Update(BasicEnemy patrolEnemy, int _invulnerable, ChaseEnemy chaseEnemy, TurretEnemy turretEnemy) {
	//If statement checks whether or not player has been damaged by the patrolEnemy.
	if (abs(getXPos() - patrolEnemy.getXPos()) <= 10 && abs(getYPos() - patrolEnemy.getYPos()) <= 10 && (patrolEnemy.getHealth() > 0) && (_invulnerable == 0)) {
		setHealth(getHealth() - patrolEnemy.getAttackDamage());
		_invulnerable = 500;
	}
	//If statement checks whether or not player has been damaged by the ChaseEnemy.
	if (abs(getXPos() - chaseEnemy.getXPos()) <= 10 && abs(getYPos() - chaseEnemy.getYPos()) <= 10 && (chaseEnemy.getHealth() > 0) && (_invulnerable == 0)) {
		setHealth(getHealth() - chaseEnemy.getAttackDamage());
		_invulnerable = 500;
	}
	if (abs(turretEnemy.getProjectile(0).getXPos() - getXPos()) < 20 && abs(turretEnemy.getProjectile(0).getYPos() - getYPos()) < 20 && (_invulnerable == 0)) {
		setHealth(getHealth() - turretEnemy.getAttackDamage());
		//cout << "Hit! PatrolEnemy Health: " << patrolEnemy.getHealth() << endl;
		_invulnerable = 500;
	}
	keyHandle();
	moveCamera();

	for (int i = 0; i < projectileArray.size(); i++) {
		if (projectileArray[i].exists) {
			projectileArray[i].Update();
		}
	}

	playerSprite.SetPosTo(xPos, yPos);
	playerSpriteFlip.SetPosTo(xPos, yPos);
	xPos += xVel;
	yPos += yVel;
	checkCollisions();
	slowDown();
	return _invulnerable;
}

void Player::shoot() {
	for (int i = 0; i < projectileArray.size(); i++) {
		if (!projectileArray[i].exists) {
			projectileArray[i] = Projectile(xPos + playerSprite.GetWidth() / 2,
				yPos + playerSprite.GetHeight() / 2,
				Mouse::GetMouseX() + Camera::getXCoord(),
				Mouse::GetMouseY() + Camera::getYCoord(),
				1,
				"Assets/Art/snowflake.png");
			break;
		}
	}
}

void Player::keyHandle() {

	if (Mouse::ButtonDown(GLFW_MOUSE_BUTTON_LEFT)) {
		shoot();
	}

	if (Keyboard::KeyDown(GLFW_KEY_W)) {
		if (hasJump) {
			if (yVel != 0) {
				hasJump = false;
			}
			yVel = 0.8;
		}
	}
	if (Keyboard::Key(GLFW_KEY_A)) {
		xVel = -0.7;
	}
	if (Keyboard::Key(GLFW_KEY_D)) {
		xVel = 0.7;
	}
}

void Player::checkCollisions() {
	GameState::restartStates = false;	//Prevents an infinite loop when the player dies in the spikes
	if (yPos < 1) {		//Makes sure that the player doesn't fall through the floor.
		yVel = 0;
		hasJump = true;
	}
	else {
		if (yVel <= -1.5) {		//Makes the player fall down when he isn't on the ground (gives the game a kind of gravity).
			yVel = -1.5;
		}
		else {
			yVel -= .003;
		}
	}

	for (int i = 0; i < blockArray.size(); i++) {

		if (yPos + playerSprite.GetHeight() > blockArray[i].getYPos() && yPos < blockArray[i].getYPos() + 64) {
			if (xPos > blockArray[i].getXPos() + 32) {
				if ((yPos + playerSprite.GetHeight()) > (blockArray[i].getYPos())) {
					if ((xPos + xVel) <= (blockArray[i].getXPos() + 64)) {
						xVel = 0;
						xPos = (blockArray[i].getXPos() + 64);
						if (blockArray[i].getBlockType() == 2) {
							GameState::restartStates = true;
						}
						if (blockArray[i].getBlockType() == 3) {
							GameState::changeStates = true;
						}
					}
				}
			}
			else {
				if (yPos < blockArray[i].getYPos() + 64) {
					if ((xPos + xVel + playerSprite.GetWidth()) >(blockArray[i].getXPos())) {
						xVel = 0;
						xPos = (blockArray[i].getXPos()) - playerSprite.GetWidth();
						if (blockArray[i].getBlockType() == 2) {
							GameState::restartStates = true;
						}
						if (blockArray[i].getBlockType() == 3) {
							GameState::changeStates = true;
						}
					}
				}
			}
		}

		if (xPos + playerSprite.GetWidth() > blockArray[i].getXPos() && xPos < blockArray[i].getXPos() + 64) {
			if (yPos > blockArray[i].getYPos() + 32) {
				if ((xPos + playerSprite.GetWidth()) > (blockArray[i].getXPos())) {
					if ((yPos + yVel) <= (blockArray[i].getYPos() + 64)) {
						yVel = 0;
						hasJump = true;
						yPos = (blockArray[i].getYPos() + 64);
						if (blockArray[i].getBlockType() == 2) {
							GameState::restartStates = true;
						}
						if (blockArray[i].getBlockType() == 3) {
							GameState::changeStates = true;
						}
					}
				}
			}
			else {
				if (xPos < blockArray[i].getXPos() + 64) {
					if ((yPos + yVel + playerSprite.GetHeight()) >(blockArray[i].getYPos())) {
						yVel = 0;
						yPos = (blockArray[i].getYPos()) - playerSprite.GetHeight();
						if (blockArray[i].getBlockType() == 2) {
							GameState::restartStates = true;
						}
						if (blockArray[i].getBlockType() == 3) {
							GameState::changeStates = true;
						}
					}
				}
			}
		}
		if (!blockArray[i].exists) {
			break;
		}
	}
}

void Player::slowDown() {	//Gives the character a deceleration rather than stopping instantly.
	if (xVel >= 0.005 || xVel <= -0.005) {
		if (xVel < 0) {
			xVel += 0.01;
		}
		if (xVel > 0) {
			xVel -= 0.01;
		}
	}
	else {
		xVel = 0;
	}
}

int Player::getAttackDamage() {
	return attackDamage;
}

void Player::setHealth(int _health) {
	health = _health;
}

float Player::getHeight() {
	return playerSprite.GetHeight();
}

float Player::getWidth() {
	return playerSprite.GetWidth();
}

float Player::getXPos() {
	return xPos;
}

float Player::getYPos() {
	return yPos;
}

int Player::getHealth() {
	return health;
}

int Player::getInitialHealth() {
	return initialHealth;
}

Projectile Player::getProjectile(int i) {
	return projectileArray[i];
}