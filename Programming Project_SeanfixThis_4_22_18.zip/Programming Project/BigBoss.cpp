#include "BigBoss.h"

BigBoss::BigBoss() {
	currentXPos = 0;
	currentYPos = 0;
	initialXPos = 0;
	initialYPos = 0;
	xVel = 0;
	yVel = 0;
	projSwitch = true;
	runAttackSet = true;
	jumpSwitch = true;
	turretSet = true;
	health = 500;
	attackDamage = 1;
	bossSprite = Sprite("Assets/Art/BigBoss.png", initialXPos, initialYPos);
	bossSprite.SetScaleTo(2);
	bossSpriteFlip = Sprite("Assets/Art/BigBossFlip.png", initialXPos, initialYPos);
	bossSpriteFlip.SetScaleTo(2);
	this->blockArray = blockArray;

}

BigBoss::BigBoss(float _xPos, float _yPos, std::array<Block, 768> blockArray) {
	currentXPos = _xPos;
	currentYPos = _yPos;
	initialXPos = _xPos;
	initialYPos = _yPos;
	xVel = 0;
	yVel = 0;
	projSwitch = true;
	runAttackSet = true;
	jumpSwitch = true;
	turretSet = true;
	health = 500;
	attackDamage = 1;
	bossSprite = Sprite("Assets/Art/BigBoss.png", initialXPos, initialYPos);
	bossSprite.SetScaleTo(2);
	bossSpriteFlip = Sprite("Assets/Art/BigBossFlip.png", initialXPos, initialYPos);
	bossSpriteFlip.SetScaleTo(2);
	this->blockArray = blockArray;
}

void BigBoss::Update(bool runattack, float playerXPos, float playerYPos) {
	//Set a path
	if (abs(playerXPos - currentXPos) < 500) {
		attack(playerXPos, playerYPos);
	}
	for (int i = 0; i < projectileArray.size(); i++) {
		if (projectileArray[i].exists) {
			projectileArray[i].Update();
		}
	}
	if (runattack)
	{
		runAttack();
	}
	else
	{
		turretMode();
	}
	Jump();
	bossSprite.SetPosTo(currentXPos, currentYPos);
	bossSpriteFlip.SetPosTo(currentXPos, currentYPos);
	currentXPos += xVel;
	currentYPos += yVel;
	checkCollisions();
}

void BigBoss::Render() {
	if (xVel <= 0)
	{
		bossSprite.Render();
	}
	else
	{
		bossSpriteFlip.Render();
	}
	
	for (int i = 0; i < projectileArray.size(); i++) {
		if (projectileArray[i].exists) {
			projectileArray[i].Render();
		}
	}
}

void BigBoss::checkCollisions() {
	if (currentYPos < 1) {
		yVel = 0;
		hasJump = true;
	}
	else {		//Makes the enemy fall down when he isn't on the ground (gives the game a kind of gravity).

		if (yVel <= -1.5) {
			yVel = -1.5;
		}
		else {
			yVel -= .003;
		}
	}
	for (int i = 0; i < blockArray.size(); i++) {	//This makes it so that the enemy doesn't go through any of the boxes.

		if (currentYPos + bossSprite.GetHeight() > blockArray[i].getYPos() && currentYPos < blockArray[i].getYPos() + 64) {
			if (currentXPos > blockArray[i].getXPos() + 32) {
				if ((currentYPos + bossSprite.GetHeight()) >(blockArray[i].getYPos())) {
					if ((currentXPos + xVel) <= (blockArray[i].getXPos() + 64)) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos() + 64);
					}
				}
			}
			else {
				if (currentYPos < blockArray[i].getYPos() + 64) {
					if ((currentXPos + xVel + bossSprite.GetWidth()) >(blockArray[i].getXPos())) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos()) - bossSprite.GetWidth();
					}
				}
			}
		}

		if (currentXPos + bossSprite.GetWidth() > blockArray[i].getXPos() && currentXPos < blockArray[i].getXPos() + 64) {
			if (currentYPos > blockArray[i].getYPos() + 32) {
				if ((currentXPos + bossSprite.GetWidth()) > (blockArray[i].getXPos())) {
					if ((currentYPos + yVel) <= (blockArray[i].getYPos() + 64)) {
						yVel = 0;
						hasJump = true;
						currentYPos = (blockArray[i].getYPos() + 64);
					}
				}
			}
			else {
				if (currentXPos < blockArray[i].getXPos() + 64) {
					if ((currentYPos + yVel + bossSprite.GetHeight()) >(blockArray[i].getYPos())) {
						yVel = 0;
						currentYPos = (blockArray[i].getYPos()) - bossSprite.GetHeight();
					}
				}
			}
		}



		if (!blockArray[i].exists) {
			break;
		}
	}
}

void BigBoss::Jump() {
	if (hasJump && jumpSwitch) {
		if (yVel != 0) {
			hasJump = false;
		}
		yVel = 1.0;
		//xVel = 0.5;
	}
}

void BigBoss::attack(float playerXPos, float playerYPos) {
	for (int i = 0; i < projectileArray.size(); i++) {
		if (!projectileArray[i].exists && projSwitch) {
			projectileArray[i] = Projectile(currentXPos + bossSprite.GetWidth() / 2,
				currentYPos + bossSprite.GetHeight() / 2,
				playerXPos,
				playerYPos,
				1.5,
				"Assets/Art/snowflake.png");
			runAttackSet = true;
			break;
		}
	}
}

void BigBoss::runAttack()
{
	if (runAttackSet)
	{
		jumpSwitch = false;
		projSwitch = false;
		currentXPos = 1920.0;
		currentYPos = 64.0;
		runAttackSet = false;
		turretSet = true;
		yVel = 0;
		
	
	}
	if (currentXPos <=  768.0)
	{
		xVel = .8;
		//currentXPos = 1920.0;
		//currentYPos = 64.0;
	}
	if (currentXPos >= 1920.0)
	{
		xVel = -.8;
	}
	

}

void BigBoss::turretMode()
{
	if (turretSet)
	{
		jumpSwitch = true;
		projSwitch = true;
		currentXPos = 1984;
		currentYPos = 256;
		turretSet = false;
		xVel = 0;
	}
	
}

void BigBoss::setHealth(int _health) {
	health = _health;
}

int BigBoss::getHealth() {
	return health;
}

int BigBoss::getAttackDamage() {
	return attackDamage;
}

float BigBoss::getXPos() {
	return currentXPos;
}

float BigBoss::getYPos() {
	return currentYPos;
}


