#include "Projectile.h"

Projectile::Projectile() {
	xPos = 0;
	yPos = 0;
	xVel = 0;
	yVel = 0;
	exists = false;
}

Projectile::Projectile(float xStart, float yStart, float xDir, float yDir, float speed, std::string spritePath) {
	xPos = xStart;
	yPos = yStart;
	xVel = ((1/(sqrt((xDir - xStart)*(xDir - xStart) + (yDir - yStart)*(yDir - yStart)))*(xDir-xStart))*speed);
	yVel = ((1/(sqrt((xDir - xStart)*(xDir - xStart) + (yDir - yStart)*(yDir - yStart)))*(yDir-yStart))*speed);
	projectileSprite = Sprite(spritePath, xStart, yStart);
	projectileSprite.SetScaleTo(1);
	//cout << ((1 / (sqrt((xDir - xStart)*(xDir - xStart) + (yDir - yStart)*(yDir - yStart)))*xDir)*speed) << endl;
	exists = true;
}

float Projectile::getXPos() {
	return xPos;
}

float Projectile::getYPos() {
	return yPos;
}

void Projectile::Update() {
	xPos += xVel;
	yPos += yVel;
	projectileSprite.SetPosTo(xPos, yPos);
	if (this->exists) {
		if ((this->getXPos() + 10) < Camera::getXCoord()) {
			this->exists = false;
		}
		if (this->getXPos() > (Camera::getXCoord() + Engine::SCREEN_WIDTH)) {
			this->exists = false;
		}
		if ((this->getYPos() + 10) < Camera::getYCoord()) {
			this->exists = false;
		}
		if (this->getYPos() > (Camera::getYCoord() + Engine::SCREEN_HEIGHT)) {
			this->exists = false;
		}
	}
}

void Projectile::Render() {
	
	projectileSprite.Render(50, 50);
}

