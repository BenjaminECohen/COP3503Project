#ifndef GAME_BACKGROUND
#define GAME_BACKGROUND

#include "Engine\Graphics\Sprite.h"
#include "Camera.h"

class Background
{
public:
	void Update();
	void Render();
	float getXPos();
	float getYPos();

	Background();



private:
	Sprite backgroundSprite;
	float xPos;
	float yPos;

};


#endif

