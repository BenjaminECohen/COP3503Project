#include "Health.h"

Health::Health(float playerXPos, float playerYPos) {
	xPos = playerXPos;
	yPos = playerXPos;
	cameraCoordX = 0;
	healthSprite = Sprite("Assets/Art/heart.png", xPos, yPos);
	healthSprite.SetScaleTo(1);
}

void Health::Update(float playerXPos, float playerYPos) {
	healthSprite.SetPosTo(playerXPos + 20, playerYPos + 20);
}

void Health::Render() {
	healthSprite.Render();
}