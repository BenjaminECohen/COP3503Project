#ifndef GAME_HEALTH
#define GAME_HEALTH

#include <iostream>
#include "Engine\Engine.h"
#include "Engine\Graphics\Sprite.h"
#include "Camera.h"

class Health {

public:
	void Update(float playerXPos, float playerYPos);
	void Render();

	Health(float playerXPos, float playerYPos);

private:
	Sprite healthSprite;
	int xPos;
	int yPos;
	int cameraCoordX;
};

#endif
