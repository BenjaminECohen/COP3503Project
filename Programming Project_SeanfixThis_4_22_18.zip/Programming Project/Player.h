#ifndef GAME_PLAYER
#define GAME_PLAYER

#include "Engine\Engine.h"
#include "Engine\Input\Keyboard.h"
#include "Engine\Input\Mouse.h"
#include "Engine\Graphics\Sprite.h"
#include "Map.h"
#include "GameState.h"
#include "Projectile.h"
#include "Camera.h"
#include "BasicEnemy.h"
#include "ChaseEnemy.h"
#include "TurretEnemy.h"

class Player {

public:
	int Update(BasicEnemy patrolEnemy, int _invulnerable, ChaseEnemy chaseEnemy, TurretEnemy turretEnemy);
	void Render();

	Player();
	Player(float xPos, float yPos, std::array<Block, 768> blockArray);

	float getXPos();
	float getYPos();
	int getHealth();
	void setHealth(int _health);
	int getAttackDamage();
	int getInitialHealth();
	float getWidth();
	float getHeight();
	//float getCameraCoordX();
	//float getCameraCoordY();
	Projectile getProjectile(int i);


private:
	Sprite playerSprite;
	Sprite playerSpriteFlip;
	std::array<Block, 768> blockArray;
	std::array<Projectile, 5> projectileArray;
	bool hasJump;
	int cameraCoordX;
	int cameraCoordY;
	void shoot();
	float xPos;
	float yPos;
	float xVel;
	float yVel;
	int health;
	int initialHealth;
	int attackDamage;
	int invulnerable;
	void checkCollisions();
	void keyHandle();
	void slowDown();
	void moveCamera();
};

#endif GAME_PLAYER
