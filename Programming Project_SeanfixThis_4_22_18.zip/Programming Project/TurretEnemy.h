#ifndef GAME_TURRETENEMY
#define GAME_TURRETENEMY

#include <cmath>
#include "Engine\Graphics\Sprite.h"
#include "Engine\Engine.h"
//#include "Player.h"
#include "Projectile.h"
#include "Map.h"

class TurretEnemy {
public:
	void Update(float playerXPos, float playerYPos);
	void Render();

	TurretEnemy();
	TurretEnemy(float _xPos, float _yPos, std::array<Block, 768> blockArray);

	float getXPos();
	float getYPos();
	int getHeight();
	int getWidth();
	int getAttackDamage();
	int getHealth();
	void setHealth(int _health);
	Projectile getProjectile(int i);

private:
	Sprite turretSprite;
	std::array<Block, 768> blockArray;
	std::array<Projectile, 1> projectileArray;
	bool hasJump;
	float currentXPos;
	float currentYPos;
	float initialXPos;
	float initialYPos;
	float xVel;
	float yVel;
	int health;
	int attackDamage;
	void checkCollisions();
	void shoot(float playerXPos, float playerYPos);
};

#endif
