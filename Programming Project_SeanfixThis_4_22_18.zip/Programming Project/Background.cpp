#include "Background.h"



Background::Background()
{
	xPos = 0;
	yPos = 0;
	backgroundSprite = Sprite("Assets/Art/Background.png", xPos, yPos);
	backgroundSprite.SetScaleTo(1);
}


void Background::Update()
{
	//Sets the background sprite to move slightly with the camera
	xPos = Camera::getXCoord()* (.33);
	backgroundSprite.SetPosTo(xPos, yPos);
	
}

void Background::Render()
{
	backgroundSprite.Render();
}