#ifndef GAME_PLAYER
#define GAME_PLAYER

#include "Engine\Engine.h"
#include "Engine\Input\Keyboard.h"
#include "Engine\Input\Mouse.h"
#include "Engine\Graphics\Sprite.h"
#include "Map.h"
#include "Projectile.h"
#include "Camera.h"

class Player {

public:
	void Update();
	void Render();
	Player();
	Player(float xPos, float yPos, std::array<Block, 768> blockArray);

	float getXPos();
	float getYPos();
	int getHealth();
	void setHealth(int _health);
	int getAttackDamage();
	int getInitialHealth();
	//void decreaseHealth();
	float getWidth();
	float getHeight();
	float getCameraCoordX();
	float getCameraCoordY();


private:
	Sprite playerSprite;
	std::array<Block, 768> blockArray;
	std::array<Projectile, 5> projectileArray;
	bool hasJump;
	int cameraCoordX;
	int cameraCoordY;
	void shoot();
	float xPos;
	float yPos;
	float xVel;
	float yVel;
	int health;
	int initialHealth;
	int attackDamage;
	void checkCollisions();
	void keyHandle();
	void slowDown();
	void moveCamera();
};

#endif GAME_PLAYER
