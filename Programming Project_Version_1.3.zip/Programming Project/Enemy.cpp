#include "Enemy.h"

//DELETE MAYBE
/*
Enemy::Enemy() {
	//empty constructor
}
Enemy::Enemy(string imagePath) {
	xPos = 0;
	yPos = 0;
	xVel = 0;
	yVel = 0;
	EnemySprite = Sprite(imagePath, xPos, yPos);
	EnemySprite.SetScaleTo(1);
}

Enemy::Enemy(string imagePath, float _xPos, float _yPos) {
	xPos = _xPos;
	yPos = _yPos;
	xVel = 0;
	yVel = 0;
	EnemySprite = Sprite(imagePath, xPos, yPos);
	EnemySprite.SetScaleTo(1);
}

void Enemy::Render() {
	EnemySprite.Render();
}*/