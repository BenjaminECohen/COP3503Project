#ifndef GAME_ENEMY
#define GAME_ENEMY

#include "Engine\Graphics\Sprite.h"
#include "Engine\Engine.h"
#include <string>

//DELETE MAYBE
/*
class Enemy {

public:
	void Render();
	Enemy();
	Enemy(string imagePath);
	Enemy(string imagePath, float _xPos, float _yPos);

private:
	//void slowDown();
	//void FlipSprite();

protected:	//Make these variables/classes protected so they can be accessed by subclasses.
	Sprite EnemySprite;
	float xPos;
	float yPos;
	float xVel;
	float yVel;
	float health;
	void checkCollisions();
};
*/

#endif
