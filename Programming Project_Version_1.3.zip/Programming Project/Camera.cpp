#include "Camera.h"

float Camera::xCoord = 0;
float Camera::yCoord = 0;

void Camera::setXCoord(float xCoord) {
	Camera::xCoord = xCoord;
}

void Camera::setYCoord(float yCoord) {
	Camera::yCoord = yCoord;
}

float Camera::getXCoord() {
	return Camera::xCoord;
}

float Camera::getYCoord() {
	return Camera::yCoord;
}
