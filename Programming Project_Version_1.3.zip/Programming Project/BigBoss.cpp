#include "BigBoss.h"

BigBoss::BigBoss() {
	currentXPos = 0;
	currentYPos = 0;
	initialXPos = 0;
	initialYPos = 0;
	xVel = 0;
	yVel = 0;
	health = 30;
	//attackDamage = 10;
	bossSprite = Sprite("Assets/Art/BigBoss.png", initialXPos, initialYPos);
	bossSprite.SetScaleTo(2);

}

BigBoss::BigBoss(float _xPos, float _yPos, std::array<Block, 768> blockArray) {
	currentXPos = _xPos;
	currentYPos = _yPos;
	initialXPos = _xPos;
	initialYPos = _yPos;
	xVel = 0;
	yVel = 0;
	health = 30;
	//attackDamage = 10;
	bossSprite = Sprite("Assets/Art/BigBoss.png", initialXPos, initialYPos);
	bossSprite.SetScaleTo(2);
	this->blockArray = blockArray;
}

void BigBoss::Update() {
	//Set a path
	Jump();
	bossSprite.SetPosTo(currentXPos, currentYPos);
	currentXPos += xVel;
	currentYPos += yVel;
	checkCollisions();
}

void BigBoss::Render() {
	bossSprite.Render();
}

void BigBoss::checkCollisions() {
	if (currentYPos < 1) {
		yVel = 0;
		hasJump = true;
	}
	else {		//Makes the enemy fall down when he isn't on the ground (gives the game a kind of gravity).

		if (yVel <= -1.5) {
			yVel = -1.5;
		}
		else {
			yVel -= .003;
		}
	}
	for (int i = 0; i < blockArray.size(); i++) {	//This makes it so that the enemy doesn't go through any of the boxes.

		if (currentYPos + bossSprite.GetHeight() > blockArray[i].getYPos() && currentYPos < blockArray[i].getYPos() + 64) {
			if (currentXPos > blockArray[i].getXPos() + 32) {
				if ((currentYPos + bossSprite.GetHeight()) >(blockArray[i].getYPos())) {
					if ((currentXPos + xVel) <= (blockArray[i].getXPos() + 64)) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos() + 64);
					}
				}
			}
			else {
				if (currentYPos < blockArray[i].getYPos() + 64) {
					if ((currentXPos + xVel + bossSprite.GetWidth()) >(blockArray[i].getXPos())) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos()) - bossSprite.GetWidth();
					}
				}
			}
		}

		if (currentXPos + bossSprite.GetWidth() > blockArray[i].getXPos() && currentXPos < blockArray[i].getXPos() + 64) {
			if (currentYPos > blockArray[i].getYPos() + 32) {
				if ((currentXPos + bossSprite.GetWidth()) > (blockArray[i].getXPos())) {
					if ((currentYPos + yVel) <= (blockArray[i].getYPos() + 64)) {
						yVel = 0;
						hasJump = true;
						currentYPos = (blockArray[i].getYPos() + 64);
					}
				}
			}
			else {
				if (currentXPos < blockArray[i].getXPos() + 64) {
					if ((currentYPos + yVel + bossSprite.GetHeight()) >(blockArray[i].getYPos())) {
						yVel = 0;
						currentYPos = (blockArray[i].getYPos()) - bossSprite.GetHeight();
					}
				}
			}
		}



		if (!blockArray[i].exists) {
			break;
		}
	}
}

void BigBoss::Jump() {
	if (hasJump) {
		if (yVel != 0) {
			hasJump = false;
		}
		yVel = 1.0;
		//xVel = 0.5;
	}
}

void BigBoss::setHealth(int _health) {
	health = _health;
}

int BigBoss::getHealth() {
	return health;
}

/*
int BigBoss::getAttackDamage() {
	return attackDamage;
}*/

float BigBoss::getXPos() {
	return currentXPos;
}

float BigBoss::getYPos() {
	return currentYPos;
}
