#include <iostream>
#include "Engine\Engine.h"
#include "Engine\Graphics\Sprite.h"
#include "Engine\Input\Mouse.h"
#include "Engine\Input\Keyboard.h"
#include "Player.h"
#include "BasicEnemy.h"
#include "ChaseEnemy.h"
#include "BigBoss.h"
#include "Health.h"
#include "Block.h"
#include "Map.h"
#include "Projectile.h"

using namespace std;

/* THINGS TO DO
- Adjust how far the player has to be from the enemy in order to get hit.
- Find a way to make the health bar move along the player.
- Find a way to give the player an attack.
- Find a way to make the chaseEnemy jump once when the player is above it.
- Find a way to add a little bit of invincibility after player gets hit.
- Change it so that instead of pressing a button to attack, the user presses left mouse button.
- Find a way to make it so that health does become negative. (use unsigned int?)
- Find a way to get rid of the monster object once that monster has 0 health.
- Figure out what the Update() method should do in the Sprite class.
- Figure out how to play sound.
- Figure out how to make the ChaseEnemy Jump when it encounters an obstacle.
*/

/* NOTES
- When a monster has 0 health, the program stops rendering it so it doesn't appear on screen. The object still exists
  but you just can't see it.
- The attack of the player should be based on direction? (The player doesn't do damage to the monster if it is
  away from it)
- Attacking the enemy doesn't always guarantee a hit even if the player is extremely close to the monster.
*/

/* ADDED 
- Health to player and monsters.
- getters for position for player and monsters.
- getters and setters for the health of player and monsters.
- Player and monster attacks (along with how much damage they do).
- An option to restart the game after the player had died.
- Stops rendering the monsters once they have 0 health (they still exist though, they're just invisible).
- Health display for the player. Hearts disappear every time player's health decreases by 1/3.
- Sword sprite gets rendered if the player successfully hits a monster.
- Gave monsters Gravity.
*/

int main() {
	while (true) {
		bool attack = false;
		Engine engine;
		engine.Init("Test");
		Map map = Map("Assets/Maps/map1.txt");
		map.LoadMap("Assets/Maps/map1.txt");
		Sprite testSprite = Sprite("Assets/Art/box.png", 500, 0);
		Sprite secondSprite = Sprite("Assets/Art/scithersword.png", 0, 500);
		Player player = Player(100, 100, map.blockArray);
		BasicEnemy patrolEnemy = BasicEnemy(100, 100, map.blockArray);
		ChaseEnemy chaseEnemy = ChaseEnemy(750, 100, map.blockArray);
		//Boss Enemy Initilization
		BigBoss boss = BigBoss(3500, 65, map.blockArray);
		Health health1 = Health(1026, 1468);
		Health health2 = Health(1046, 1468);
		Health health3 = Health(1066, 1468);
		Projectile projectile;
		
		Block block = Block(100, 100);

		testSprite.SetScaleTo(1);
		secondSprite.SetScaleTo(1);


		while (true) {
			if (Mouse::ButtonDown(GLFW_MOUSE_BUTTON_LEFT)) {
				//projectile = Projectile(player.getXPos() + player.getWidth()/2, player.getYPos() + player.getHeight()/2, Mouse::GetMouseX(), Mouse::GetMouseY(), 1, "Assets/Art/snowflake.png");

			}

			attack = false;
			if (player.getHealth() <= 0) {
				break;
			}
			engine.Update();
			if ((abs(player.getXPos() - chaseEnemy.getXPos()) < 300)) {
				chaseEnemy.Update(true, player.getXPos());	//ChaseEnemy chases the player
			}
			else {
				chaseEnemy.Update(false, player.getXPos());	//ChaseEnemy patrols and doesn't chase the player.
			}
			//If statement checks whether or not player has been damaged by the patrolEnemy.
			if (abs(player.getXPos() - patrolEnemy.getXPos()) < 1 && abs(player.getYPos() - patrolEnemy.getYPos()) < 1 && (patrolEnemy.getHealth() > 0)) {
				player.setHealth(player.getHealth() - patrolEnemy.getAttackDamage());
				cout << "Hit! Player Health: " << player.getHealth() << endl;
			}
			//If statement checks whether or not player has been damaged by the ChaseEnemy.
			if (abs(player.getXPos() - chaseEnemy.getXPos()) < 1 && abs(player.getYPos() - chaseEnemy.getYPos()) < 1 && (chaseEnemy.getHealth() > 0)) {
				player.setHealth(player.getHealth() - chaseEnemy.getAttackDamage());
				cout << "Hit! Player Health: " << player.getHealth() << endl;
			}
			//If statement checks whether or not player damages patrolEnemy.
			if (abs(player.getXPos() - patrolEnemy.getXPos()) < 15 && abs(player.getYPos() - patrolEnemy.getYPos()) < 15 && (Keyboard::KeyDown(GLFW_KEY_K))) {
				patrolEnemy.setHealth(patrolEnemy.getHealth() - player.getAttackDamage());
				cout << "Hit! PatrolEnemy Health: " << patrolEnemy.getHealth() << endl;
				attack = true;
			}
			//If statement checks whether or not player damages ChaseEnemy.
			if (abs(player.getXPos() - chaseEnemy.getXPos()) < 15 && abs(player.getYPos() - chaseEnemy.getYPos()) < 15 && (Keyboard::KeyDown(GLFW_KEY_K))) {
				chaseEnemy.setHealth(chaseEnemy.getHealth() - player.getAttackDamage());
				cout << "Hit! ChaseEnemy Health: " << chaseEnemy.getHealth() << endl;
				attack = true;
			}
			if (player.getHealth() >= 333) {
				health1.Update();
				health2.Update();
				health3.Update();
			}
			else if ((player.getHealth() < 333) && (player.getHealth() >= 166)) {
				health1.Update();
				health2.Update();
			}
			else if ((player.getHealth() < 333) && player.getInitialHealth() > 0) {
				health1.Update();
			}
			else {
			}

			//Sprite Updates
			player.Update();
			patrolEnemy.Update();
			boss.Update();
			testSprite.Update();
			secondSprite.Update();
			block.Update();
			projectile.Update();

			//Start of the Rendering of Objects/Sprites and Keyboard buttons pressing
			engine.BeginRender();
			if (player.getHealth() >= 333) {
				health1.Render();
				health2.Render();
				health3.Render();
			}
			else if ((player.getHealth() < 333) && (player.getHealth() >= 166)) {
				health1.Render();
				health2.Render();
			}
			else if ((player.getHealth() < 333) && player.getInitialHealth() > 0) {
				health1.Render();
			}
			else {
			}
			if (attack || Keyboard::KeyDown(GLFW_KEY_K)) {
				secondSprite.Render();
			}
			player.Render();
			if (!(patrolEnemy.getHealth() <= 0)) {	//Only renders patrol enemy if it has health;
				patrolEnemy.Render();
			}
			if (!(chaseEnemy.getHealth() <= 0)) {		//Only renders chase enemy if it has health;
				chaseEnemy.Render();
			}
			//Rendering BigBoss
			boss.Render();
			projectile.Render();

			map.Render();
			//testSprite.Render();


			engine.EndRender();
			//End of rendering

		}
		string userInput;
		cout << "Game over! You have died!" << endl;
		cout << "Would you like to play again? (enter y or n)" << endl;
		cin >> userInput;
		if (userInput.compare("y") == 0) {
			continue;
		}
		else {
			break;
		}
	}

	return 0;
}