#include "BasicEnemy.h"

BasicEnemy::BasicEnemy() {
	currentXPos = 0;
	currentYPos = 0;
	initialXPos = 0;
	initialYPos = 0;
	xVel = 0;
	yVel = 0;
	health = 20;
	attackDamage = 5;
	basicEnemySprite = Sprite("Assets/Art/wolf.png", initialXPos, initialYPos);
	basicEnemySprite.SetScaleTo(1);
}

BasicEnemy::BasicEnemy(float _xPos, float _yPos, std::array<Block, 768> blockArray) {
	currentXPos = _xPos;
	currentYPos = _yPos;
	initialXPos = _xPos;
	initialYPos = _yPos;
	xVel = 0;
	yVel = 0;
	health = 20;
	attackDamage = 5;
	basicEnemySprite = Sprite("Assets/Art/wolf.png", initialXPos, initialYPos);
	basicEnemySprite.SetScaleTo(1);
	this->blockArray = blockArray;
}

void BasicEnemy::Render() {
	basicEnemySprite.Render();
}

void BasicEnemy::Update() {
	Patrol();
	basicEnemySprite.SetPosTo(currentXPos, currentYPos);
	currentXPos += xVel;
	currentYPos += yVel;
	checkCollisions();
}


void BasicEnemy::checkCollisions() {
	if (currentYPos < 1) {
		yVel = 0;
	}
	else {		//Makes the enemy fall down when he isn't on the ground (gives the game a kind of gravity).

		if (yVel <= -1.5) {
			yVel = -1.5;
		}
		else {
			yVel -= .003;
		}
	}
	for (int i = 0; i < blockArray.size(); i++) {

		if (currentYPos + basicEnemySprite.GetHeight() > blockArray[i].getYPos() && currentYPos < blockArray[i].getYPos() + 64) {
			if (currentXPos > blockArray[i].getXPos() + 32) {
				if ((currentYPos + basicEnemySprite.GetHeight()) >(blockArray[i].getYPos())) {
					if ((currentXPos + xVel) <= (blockArray[i].getXPos() + 64)) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos() + 64);
					}
				}
			}
			else {
				if (currentYPos < blockArray[i].getYPos() + 64) {
					if ((currentXPos + xVel + basicEnemySprite.GetWidth()) >(blockArray[i].getXPos())) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos()) - basicEnemySprite.GetWidth();
					}
				}
			}
		}

		if (currentXPos + basicEnemySprite.GetWidth() > blockArray[i].getXPos() && currentXPos < blockArray[i].getXPos() + 64) {
			if (currentYPos > blockArray[i].getYPos() + 32) {
				if ((currentXPos + basicEnemySprite.GetWidth()) > (blockArray[i].getXPos())) {
					if ((currentYPos + yVel) <= (blockArray[i].getYPos() + 64)) {
						yVel = 0;
						//hasJump = true;
						currentYPos = (blockArray[i].getYPos() + 64);
					}
				}
			}
			else {
				if (currentXPos < blockArray[i].getXPos() + 64) {
					if ((currentYPos + yVel + basicEnemySprite.GetHeight()) >(blockArray[i].getYPos())) {
						yVel = 0;
						currentYPos = (blockArray[i].getYPos()) - basicEnemySprite.GetHeight();
					}
				}
			}
		}



		if (!blockArray[i].exists) {
			break;
		}
	}
}

void BasicEnemy::Patrol() {
	if (currentXPos <= initialXPos) {
		xVel = 0.6;
	}
	if (currentXPos > initialXPos + 500) {
		xVel = -0.6;
	}
}

void BasicEnemy::setHealth(int _health) {
	health = _health;
}

int BasicEnemy::getHealth() {
	return health;
}

int BasicEnemy::getAttackDamage() {
	return attackDamage;
}

float BasicEnemy::getXPos() {
	return currentXPos;
}

float BasicEnemy::getYPos() {
	return currentYPos;
}

/*
void Enemy::FlipSprite() {
	if (xPos == 500) {
		flipSprite = true;
	}
}
*/
