#include "ChaseEnemy.h"

ChaseEnemy::ChaseEnemy() {
	currentXPos = 0;
	currentYPos = 0;
	initialXPos = 0;
	initialYPos = 0;
	xVel = 0;
	yVel = 0;
	health = 300;
	attackDamage = 1;
	chaseEnemySprite = Sprite("Assets/Art/Robot_Enemy_Cropped.png", initialXPos, initialYPos);
	chaseEnemySprite.SetScaleTo(1);
	exists = false;
}

void ChaseEnemy::setProjectileArray(std::array<Projectile, 5> projectileArray) {
	this->projectileArray = projectileArray;
}


ChaseEnemy::ChaseEnemy(float _xPos, float _yPos, std::array<Block, 100> blockArray, std::array<Projectile, 5> projectileArray) {
	currentXPos = _xPos;
	currentYPos = _yPos;
	initialXPos = _xPos;
	initialYPos = _yPos;
	xVel = 0;
	yVel = 0;
	health = 300;
	attackDamage = 1;
	chaseEnemySprite = Sprite("Assets/Art/Robot_Enemy_Cropped.png", initialXPos, initialYPos);
	chaseEnemySprite.SetScaleTo(1);
	this->blockArray = blockArray;
	this->projectileArray = projectileArray;
	exists = true;
}

void ChaseEnemy::Update(float playerXPos) {
	if (std::abs(currentXPos - playerXPos) < 300) {
		ChasePlayer(playerXPos);
	}
	else {	
		//Patrol();
	}
	Jump();
	chaseEnemySprite.SetPosTo(currentXPos, currentYPos);
	currentXPos += xVel;
	currentYPos += yVel;
	checkCollisions();
	checkDeath();
}

void ChaseEnemy::checkDeath() {
	if (health <= 0) {
		exists = false;
	}
}

void ChaseEnemy::Render() {
	chaseEnemySprite.Render();
}

void ChaseEnemy::checkCollisions() {
	if (currentYPos < 1) {
		yVel = 0;
		hasJump = true;
	}
	else {		//Makes the enemy fall down when he isn't on the ground (gives the game a kind of gravity).

		if (yVel <= -1.5) {
			yVel = -1.5;
		}
		else {
			yVel -= .003;
		}
	}
	for (int i = 0; i < blockArray.size(); i++) {	//This makes it so that the enemy doesn't go through any of the boxes.

		if (currentYPos + chaseEnemySprite.GetHeight() > blockArray[i].getYPos() && currentYPos < blockArray[i].getYPos() + 64) {
			if (currentXPos > blockArray[i].getXPos() + 32) {
				if ((currentYPos + chaseEnemySprite.GetHeight()) >(blockArray[i].getYPos())) {
					if ((currentXPos + xVel) <= (blockArray[i].getXPos() + 64)) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos() + 64);
					}
				}
			}
			else {
				if (currentYPos < blockArray[i].getYPos() + 64) {
					if ((currentXPos + xVel + chaseEnemySprite.GetWidth()) >(blockArray[i].getXPos())) {
						xVel = 0;
						currentXPos = (blockArray[i].getXPos()) - chaseEnemySprite.GetWidth();
					}
				}
			}
		}

		if (currentXPos + chaseEnemySprite.GetWidth() > blockArray[i].getXPos() && currentXPos < blockArray[i].getXPos() + 64) {
			if (currentYPos > blockArray[i].getYPos() + 32) {
				if ((currentXPos + chaseEnemySprite.GetWidth()) > (blockArray[i].getXPos())) {
					if ((currentYPos + yVel) <= (blockArray[i].getYPos() + 64)) {
						yVel = 0;
						hasJump = true;
						currentYPos = (blockArray[i].getYPos() + 64);
					}
				}
			}
			else {
				if (currentXPos < blockArray[i].getXPos() + 64) {
					if ((currentYPos + yVel + chaseEnemySprite.GetHeight()) >(blockArray[i].getYPos())) {
						yVel = 0;
						currentYPos = (blockArray[i].getYPos()) - chaseEnemySprite.GetHeight();
					}
				}
			}
		}



		if (!blockArray[i].exists) {
			break;
		}
	}
	for (int i = 0; i < projectileArray.size(); i++) {

		if (projectileArray[i].exists) {
			if (currentYPos + chaseEnemySprite.GetHeight() > projectileArray[i].getYPos() && currentYPos < projectileArray[i].getYPos() + projectileArray[i].getHeight()) {
				if (currentXPos > projectileArray[i].getXPos() + projectileArray[i].getWidth() / 2) {
					if ((currentYPos + chaseEnemySprite.GetHeight()) > (projectileArray[i].getYPos())) {
						if ((currentXPos + xVel) <= (projectileArray[i].getXPos() + projectileArray[i].getWidth())) {
							projectileArray[i].exists = false;
							setHealth(getHealth() - 1);
							//cout << "hit" << endl;
						}
					}
				}
				else {
					if (currentYPos < projectileArray[i].getYPos() + projectileArray[i].getHeight()) {
						if ((currentXPos + xVel + chaseEnemySprite.GetWidth()) >(projectileArray[i].getXPos())) {
							projectileArray[i].exists = false;
							setHealth(getHealth() - 1);
							//cout << "hit" << endl;
						}
					}
				}
			}

			if (currentXPos + chaseEnemySprite.GetWidth() > projectileArray[i].getXPos() && currentXPos < projectileArray[i].getXPos() + projectileArray[i].getWidth()) {
				if (currentYPos > projectileArray[i].getYPos() + projectileArray[i].getWidth() / 2) {
					if ((currentXPos + chaseEnemySprite.GetWidth()) > (projectileArray[i].getXPos())) {
						if ((currentYPos + yVel) <= (projectileArray[i].getYPos() + projectileArray[i].getHeight())) {
							projectileArray[i].exists = false;
							setHealth(getHealth() - 1);
							//cout << "hit" << endl;
						}
					}
				}
				else {
					if (currentXPos < projectileArray[i].getXPos() + projectileArray[i].getWidth()) {
						if ((currentYPos + yVel + chaseEnemySprite.GetHeight()) >(projectileArray[i].getYPos())) {
							projectileArray[i].exists = false;
							setHealth(getHealth() - 1);
							//cout << "hit" << endl;
						}
					}
				}
			}
		}
	}
}

void ChaseEnemy::Patrol() {
	if (currentXPos <= initialXPos) {
		xVel = 0.5;
	}
	if (currentXPos > initialXPos + 500) {
		xVel = -0.5;
	}
}

void ChaseEnemy::Jump() {
	if (hasJump) {
		if (yVel != 0) {
			hasJump = false;
		}
		yVel = 0.7;
	}
}

void ChaseEnemy::ChasePlayer(float playerXPos) {
	if (playerXPos > currentXPos) {
		xVel = 0.4;
	}
	else {
		xVel = -0.4;
	}
}

void ChaseEnemy::setHealth(int _health) {
	health = _health;
}

int ChaseEnemy::getHealth() {
	return health;
}

int ChaseEnemy::getAttackDamage() {
	return attackDamage;
}

float ChaseEnemy::getXPos() {
	return currentXPos;
}

float ChaseEnemy::getYPos() {
	return currentYPos;
}

int ChaseEnemy::getHeight() {
	return chaseEnemySprite.GetHeight();
}

int ChaseEnemy::getWidth() {
	return chaseEnemySprite.GetWidth();
}