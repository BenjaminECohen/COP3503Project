#include <iostream>
#include "Engine\Engine.h"
#include "Engine\Graphics\Sprite.h"
#include "Engine\Input\Mouse.h"
#include "Engine\Input\Keyboard.h"
#include "Player.h"
#include "Map.h"
#include "Block.h"

using namespace std;

int main() {

	Engine engine;
	engine.Init("Test");
	Sprite testSprite = Sprite("Assets/Art/box.png", 500, 0);
	Sprite secondSprite = Sprite("Assets/Art/scithersword.png", 2500, 0);
	Block block = Block(100, 100);
	Map map = Map("Assets/Maps/map1.txt");
	map.LoadMap("Assets/Maps/map1.txt");
	Player player = Player(0, 100, map.blockArray);

	testSprite.SetScaleTo(1);
	secondSprite.SetScaleTo(1);


	while (true) {

		

		engine.Update();
		player.Update();
		testSprite.Update();
		secondSprite.Update();
		block.Update();


		engine.BeginRender();
		map.Render();
		player.Render();
		
		
		engine.EndRender();
	}

	return 0;
}