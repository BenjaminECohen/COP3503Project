#include <iostream>
#include "Engine\Engine.h"
#include "Engine\Graphics\Sprite.h"
#include "Engine\Input\Mouse.h"
#include "Engine\Input\Keyboard.h"
#include "Player.h"
#include "Map.h"
#include "Block.h"
#include "Projectile.h"

using namespace std;

int main() {

	Engine engine;
	engine.Init("Test");
	Map map = Map("Assets/Maps/map1.txt");
	map.LoadMap("Assets/Maps/map1.txt");
	Player player = Player(0, 100, map.blockArray);
	Projectile projectile;

	while (true) {

		if (Mouse::ButtonDown(GLFW_MOUSE_BUTTON_LEFT)) {
			//projectile = Projectile(player.getXPos() + player.getWidth()/2, player.getYPos() + player.getHeight()/2, Mouse::GetMouseX(), Mouse::GetMouseY(), 1, "Assets/Art/snowflake.png");

		}

		engine.Update();
		player.Update();
		projectile.Update();
		


		engine.BeginRender();
		map.Render();
		player.Render();
		projectile.Render();
		
		
		engine.EndRender();
	}

	return 0;
}