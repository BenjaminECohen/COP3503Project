#include "Map.h"

Map::Map(std::string mapFile) {
	mapString = "";
}


void Map::Render() {

	for (int i = 0; i < blockArray.size(); i++) {
		if (blockArray[i].exists) {
			blockArray[i].Render();
		}
	}

}

void Map::Update(){

}

void Map::LoadMap(std::string mapFile) {

	std::ifstream input;
	std::string mapString;
	input.open("Assets/Maps/map1.txt");
	std::array<std::string, 12> map;
	int count = 0;

	while (!input.eof()) {
		input >> map[count];
		count++;
	}
	count = 0;

	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 64; j++) {
			if (map[i].at(j) == '1') {
				blockArray[count] = Block(j * 64, ((11 - i) * 64));
				count++;
				cout << "1";
			}
			else {
				cout << "0";
			}
		}
		cout << endl;
	}
}