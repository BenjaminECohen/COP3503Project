#pragma once
#include "Engine\Graphics\Sprite.h" 
#include <string>
#include <math.h>
#include "Camera.h"
#include "Engine\Engine.h"

class Projectile {
public:
	Projectile();
	Projectile(float xStart, float yStart, float xDir, float yDir, float speed, std::string spritePath);
	float getXPos();
	float getYPos();
	bool exists;
	void Update();
	void Render();

private:
	Sprite projectileSprite;
	float xPos;
	float yPos;
	float xVel;
	float yVel;


};