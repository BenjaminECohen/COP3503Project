#include "Player.h"

Player::Player() {
	xPos = 0;
	yPos = 0;
	xVel = 0;
	yVel = 0;
	Camera::setXCoord(0);
	Camera::setYCoord(0);
	playerSprite = Sprite("Assets/Art/bad-character.png", xPos, yPos);
	playerSprite.SetScaleTo(1);
}

Player::Player(float xPos, float yPos, std::array<Block, 768> blockArray) {
	this->xPos = xPos;
	this->yPos = yPos;
	xVel = 0;
	yVel = 0;
	Camera::setXCoord(0);
	Camera::setYCoord(0);
	playerSprite = Sprite("Assets/Art/bad-character.png", xPos, yPos);
	playerSprite.SetScaleTo(1);
	this->blockArray = blockArray;
}

void Player::Render() {
	playerSprite.Render();
	for (int i = 0; i < projectileArray.size(); i++) {
		if (projectileArray[i].exists) {
			projectileArray[i].Render();
		}
	}
}

void Player::moveCamera() {

	if (xPos - Camera::getXCoord() > Engine::SCREEN_WIDTH*(.66)) {
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(xPos - Engine::SCREEN_WIDTH*(.66), xPos + Engine::SCREEN_WIDTH*(.33), 0, Engine::SCREEN_HEIGHT, -10, 10);
		glMatrixMode(GL_MODELVIEW);
		Camera::setXCoord(xPos - Engine::SCREEN_WIDTH*(.66));
	}
	if (xPos - Camera::getXCoord() < Engine::SCREEN_WIDTH*(.33) && xPos > Engine::SCREEN_WIDTH*(.33)) {
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(xPos - Engine::SCREEN_WIDTH*(.33), xPos + Engine::SCREEN_WIDTH*(.66), 0, Engine::SCREEN_HEIGHT, -10, 10);
		glMatrixMode(GL_MODELVIEW);
		Camera::setXCoord(xPos - Engine::SCREEN_WIDTH*(.33));
	}

}



void Player::Update() {
	keyHandle();
	moveCamera();
	for (int i = 0; i < projectileArray.size(); i++) {
		if (projectileArray[i].exists) {
			projectileArray[i].Update();
		}
	}

	playerSprite.SetPosTo(xPos, yPos);
	xPos += xVel;
	yPos += yVel;
	checkCollisions();
	slowDown();
}

void Player::shoot() {
	for (int i = 0; i < projectileArray.size(); i++) {
		if (!projectileArray[i].exists) {
			projectileArray[i] = Projectile(xPos + playerSprite.GetWidth() / 2, 
								yPos + playerSprite.GetHeight() / 2, 
								Mouse::GetMouseX() + Camera::getXCoord(), 
								Mouse::GetMouseY() + Camera::getYCoord(), 
								1, 
								"Assets/Art/snowflake.png");
			break;
		}
	}
}

float Player::getHeight() {
	return playerSprite.GetHeight();
}

float Player::getWidth() {
	return playerSprite.GetWidth();
}

float Player::getXPos() {
	return xPos;
}

float Player::getYPos() {
	return yPos;
}

void Player::keyHandle() {

	if (Mouse::ButtonDown(GLFW_MOUSE_BUTTON_LEFT)) {
		shoot();
	}

	if (Keyboard::KeyDown(GLFW_KEY_W)) {
		if (hasJump) {
			if (yVel != 0) {
				hasJump = false;
			}
			yVel = .8;
		}
	}
	if (Keyboard::Key(GLFW_KEY_A)) {
		xVel = -.7;
	}
	if (Keyboard::Key(GLFW_KEY_D)) {
		xVel = .7;
	}
}

void Player::checkCollisions() {

	if (yPos < 1) {
		yVel = 0;
		hasJump = true;
	}
	else {
		if (yVel <= -1.5) {
			yVel = -1.5;
		}
		else {
			yVel -= .003;
		}
	}



	for (int i = 0; i < blockArray.size(); i++) {

		if (yPos + playerSprite.GetHeight() > blockArray[i].getYPos() && yPos < blockArray[i].getYPos() + 64) {
			if (xPos > blockArray[i].getXPos() + 32) {
				if ((yPos + playerSprite.GetHeight()) > (blockArray[i].getYPos())) {
					if ((xPos + xVel) <= (blockArray[i].getXPos() + 64)) {
						xVel = 0;
						xPos = (blockArray[i].getXPos() + 64);
					}
				}
			}
			else {
				if (yPos < blockArray[i].getYPos() + 64) {
					if ((xPos + xVel + playerSprite.GetWidth()) > (blockArray[i].getXPos())) {
						xVel = 0;
						xPos = (blockArray[i].getXPos()) - playerSprite.GetWidth();
					}
				}
			}
		}

		if (xPos + playerSprite.GetWidth() > blockArray[i].getXPos() && xPos < blockArray[i].getXPos() + 64) {
			if (yPos > blockArray[i].getYPos() + 32) {
				if ((xPos + playerSprite.GetWidth()) > (blockArray[i].getXPos())) {
					if ((yPos + yVel) <= (blockArray[i].getYPos() + 64)) {
						yVel = 0;
						hasJump = true;
						yPos = (blockArray[i].getYPos() + 64);
					}
				}
			}
			else {
				if(xPos < blockArray[i].getXPos() + 64) {
					if ((yPos + yVel + playerSprite.GetHeight()) > (blockArray[i].getYPos())) {
						yVel = 0;
						yPos = (blockArray[i].getYPos()) - playerSprite.GetHeight();
					}
				}
			}
		}

		

		if (!blockArray[i].exists) {
			break;
		}
	}
}

void Player::slowDown() {
	if (xVel >= .005 || xVel <= -.005) {
		if (xVel < 0) {
			xVel += .0025;
		}
		if (xVel > 0) {
			xVel -= .0025;
		}
	}
	else {
		xVel = 0;
	}
}