#include "Player.h"

Player::Player() {
	xPos = 0;
	yPos = 0;
	xVel = 0;
	yVel = 0;
	cameraCoordX = 0;
	cameraCoordY = 0;
	health = 500;
	initialHealth = 500;
	attackDamage = 10;
	playerSprite = Sprite("Assets/Art/bad-character.png", xPos, yPos);
	playerSprite.SetScaleTo(1);
}

Player::Player(float xPos, float yPos, std::array<Block, 768> blockArray) {
	this->xPos = xPos;
	this->yPos = yPos;
	xVel = 0;
	yVel = 0;
	cameraCoordX = 0;
	cameraCoordY = 0;
	health = 500;
	initialHealth = 500;
	attackDamage = 10;
	playerSprite = Sprite("Assets/Art/bad-character.png", xPos, yPos);
	playerSprite.SetScaleTo(1);
	this->blockArray = blockArray;
}

void Player::Render() {
	playerSprite.Render();
}

void Player::moveCamera() {
	if (xPos - cameraCoordX > Engine::SCREEN_WIDTH*(0.66)) {
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(xPos - Engine::SCREEN_WIDTH*(0.66), xPos + Engine::SCREEN_WIDTH*(0.33), 0, Engine::SCREEN_HEIGHT, -10, 10);
		glMatrixMode(GL_MODELVIEW);
		cameraCoordX = xPos - Engine::SCREEN_WIDTH*(0.66);
	}
	if (xPos - cameraCoordX < Engine::SCREEN_WIDTH*(0.33) && xPos > Engine::SCREEN_WIDTH*(0.33)) {
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(xPos - Engine::SCREEN_WIDTH*(0.33), xPos + Engine::SCREEN_WIDTH*(0.66), 0, Engine::SCREEN_HEIGHT, -10, 10);
		glMatrixMode(GL_MODELVIEW);
		cameraCoordX = xPos - Engine::SCREEN_WIDTH*(0.33);
	}
}

void Player::Update() {
	keyHandle();
	moveCamera();

	playerSprite.SetPosTo(xPos, yPos);
	xPos += xVel;
	yPos += yVel;
	checkCollisions();
	slowDown();
}

int Player::getAttackDamage() {
	return attackDamage;
}

void Player::keyHandle() {
	if (Keyboard::KeyDown(GLFW_KEY_W)) {
		if (hasJump) {
			if (yVel != 0) {
				hasJump = false;
			}
			yVel = 0.8;
		}
	}
	if (Keyboard::Key(GLFW_KEY_A)) {
		xVel = -0.7;
	}
	if (Keyboard::Key(GLFW_KEY_D)) {
		xVel = 0.7;
	}
}
void Player::checkCollisions() {
	if (yPos < 1) {		//Makes sure that the player doesn't fall through the floor.
		yVel = 0;
		hasJump = true;
	}
	else {		//Makes the player fall down when he isn't on the ground (gives the game a kind of gravity).
		
		if (yVel <= -1.5) {
			yVel = -1.5;
		}
		else {
			yVel -= .003;
		}
	}
	for (int i = 0; i < blockArray.size(); i++) {

		if (yPos + playerSprite.GetHeight() > blockArray[i].getYPos() && yPos < blockArray[i].getYPos() + 64) {
			if (xPos > blockArray[i].getXPos() + 32) {
				if ((yPos + playerSprite.GetHeight()) > (blockArray[i].getYPos())) {
					if ((xPos + xVel) <= (blockArray[i].getXPos() + 64)) {
						xVel = 0;
						xPos = (blockArray[i].getXPos() + 64);
					}
				}
			}
			else {
				if (yPos < blockArray[i].getYPos() + 64) {
					if ((xPos + xVel + playerSprite.GetWidth()) >(blockArray[i].getXPos())) {
						xVel = 0;
						xPos = (blockArray[i].getXPos()) - playerSprite.GetWidth();
					}
				}
			}
		}

		if (xPos + playerSprite.GetWidth() > blockArray[i].getXPos() && xPos < blockArray[i].getXPos() + 64) {
			if (yPos > blockArray[i].getYPos() + 32) {
				if ((xPos + playerSprite.GetWidth()) > (blockArray[i].getXPos())) {
					if ((yPos + yVel) <= (blockArray[i].getYPos() + 64)) {
						yVel = 0;
						hasJump = true;
						yPos = (blockArray[i].getYPos() + 64);
					}
				}
			}
			else {
				if (xPos < blockArray[i].getXPos() + 64) {
					if ((yPos + yVel + playerSprite.GetHeight()) >(blockArray[i].getYPos())) {
						yVel = 0;
						yPos = (blockArray[i].getYPos()) - playerSprite.GetHeight();
					}
				}
			}
		}



		if (!blockArray[i].exists) {
			break;
		}
	}
}

void Player::slowDown() {	//Gives the character a deceleration rather than stopping instantly.
	if (xVel >= 0.005 || xVel <= -0.005) {
		if (xVel < 0) {
			xVel += 0.0015;
		}
		if (xVel > 0) {
			xVel -= 0.0015;
		}
	}
	else {
		xVel = 0;
	}
}

void Player::setHealth(int _health) {
	health = _health;
}

/*
void Player::decreaseHealth() {
	health -= 5;
}*/

float Player::getXPos() {
	return xPos;
}

float Player::getYPos() {
	return yPos;
}

int Player::getHealth() {
	return health;
}

int Player::getInitialHealth() {
	return initialHealth;
}