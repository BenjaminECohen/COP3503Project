#include "Health.h"

Health::Health(int _xPos, int _yPos) {
	xPos = _xPos;
	yPos = _yPos;
	cameraCoordX = 0;
	healthSprite = Sprite("Assets/Art/heart.png", xPos, yPos);
	healthSprite.SetScaleTo(1);
}

void Health::move() {
	if (xPos - cameraCoordX > Engine::SCREEN_WIDTH*(0.66)) {
		cameraCoordX = xPos - Engine::SCREEN_WIDTH*(0.66);
	}
	if (xPos - cameraCoordX < Engine::SCREEN_WIDTH*(0.33) && xPos > Engine::SCREEN_WIDTH*(0.33)) {
		cameraCoordX = xPos - Engine::SCREEN_WIDTH*(0.33);
	}
	xPos = cameraCoordX;
}

void Health::Update() {
	move();
	healthSprite.SetPosTo(xPos, yPos - Engine::SCREEN_HEIGHT);
}

void Health::Render() {
	healthSprite.Render();
}