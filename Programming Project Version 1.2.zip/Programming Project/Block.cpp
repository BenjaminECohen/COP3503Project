#include "Block.h"

int Block::BLOCK_HEIGHT = 64;
int Block::BLOCK_WIDTH = 64;

Block::Block(int xPos, int yPos) {
	this->xPos = xPos;
	this->yPos = yPos;
	Block::blockSprite = Sprite("Assets/Art/box.png", xPos, yPos);
	blockSprite.SetScaleTo(1);
	exists = 1;
}

int Block::getXPos() {
	return xPos;
}

int Block::getYPos() {
	return yPos;
}

Block::Block() {
	exists = 0;
}

void Block::Render() {
	blockSprite.Render(BLOCK_WIDTH, BLOCK_HEIGHT);
}

void Block::Update() {

}