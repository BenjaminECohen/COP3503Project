#ifndef GAME_HEALTH
#define GAME_HEALTH

#include "Engine\Engine.h"
#include "Engine\Graphics\Sprite.h"

class Health {

public:
	void Update();
	void Render();

	Health(int _xPos, int _yPos);
	void move();

private:
	Sprite healthSprite;
	int xPos;
	int yPos;
	int cameraCoordX;
};

#endif
