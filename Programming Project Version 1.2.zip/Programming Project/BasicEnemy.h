#ifndef GAME_BASICENEMY
#define GAME_BASICENEMY

#include "Engine\Graphics\Sprite.h"
#include "Engine\Engine.h"
#include "Map.h"

class BasicEnemy {
public:
	void Update();
	void Render();

	BasicEnemy();
	BasicEnemy(float _xPos, float _yPos, std::array<Block, 768> blockArray);

	float getXPos();
	float getYPos();
	int getAttackDamage();
	void setHealth(int _health);
	int getHealth();

private:
	Sprite basicEnemySprite;
	std::array<Block, 768> blockArray;
	float currentXPos;
	float currentYPos;
	float initialXPos;
	float initialYPos;
	float xVel;
	float yVel;
	int health;
	int attackDamage;
	void checkCollisions();
	void Patrol();
};

#endif
