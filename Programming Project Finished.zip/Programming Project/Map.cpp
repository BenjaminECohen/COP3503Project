#include "Map.h"

Map::Map(std::string mapFile) {
	mapString = "";
}

Map::Map() {
	mapString = "";
}

void Map::setProjectileArray(std::array<Projectile, 5> projectileArray) {
	this->projectileArray = projectileArray;
}

void Map::setPlayerPos(float playerXPos, float playerYPos) {
	this->playerXPos = playerXPos;
	this->playerYPos = playerYPos;
}

void Map::Render() {

	for (int i = 0; i < blockArray.size(); i++) {
		if (blockArray[i].exists) {
			blockArray[i].Render();
		}
	}

	for (int i = 0; i < basicEnemyArray.size(); i++) {
		if (basicEnemyArray[i].exists) {
			basicEnemyArray[i].Render();
		}
	}

	for (int i = 0; i < chaseEnemyArray.size(); i++) {
		if (chaseEnemyArray[i].exists) {
			chaseEnemyArray[i].Render();
		}
	}
	for (int i = 0; i < turretEnemyArray.size(); i++) {
		if (turretEnemyArray[i].exists) {
			turretEnemyArray[i].Render();
		}
	}

	if (bigBoss.exists) {
		bigBoss.Render();
	}

}

void Map::Update(){
	for (int i = 0; i < basicEnemyArray.size(); i++) {
		if (basicEnemyArray[i].exists) {
			basicEnemyArray[i].Update();
			basicEnemyArray[i].setProjectileArray(projectileArray);
		}
	}

	for (int i = 0; i < chaseEnemyArray.size(); i++) {
		if (chaseEnemyArray[i].exists) {
			chaseEnemyArray[i].Update(playerXPos);
			chaseEnemyArray[i].setProjectileArray(projectileArray);
		}
	}

	for (int i = 0; i < turretEnemyArray.size(); i++) {
		if (turretEnemyArray[i].exists) {
			turretEnemyArray[i].Update(playerXPos, playerYPos);
			turretEnemyArray[i].setPlayerProjectileArray(projectileArray);
		}
	}

	if (bigBoss.exists){
		bigBoss.Update(playerXPos, playerYPos);
		bigBoss.setPlayerProjectileArray(projectileArray);
	}
}

void Map::LoadMap(std::string mapFile) {

	std::ifstream input;
	std::string mapString;
	input.open(mapFile);
	std::array<std::string, 12> map;
	int count = 0;
	int basicEnemyCount = 0;

	while (!input.eof()) {
		input >> map[count];
		count++;
	}
	count = 0;
	basicEnemyCount = 0;
	chaseEnemyCount = 0;
	turretEnemyCount = 0;

	for (int i = 0; i < blockArray.size(); i++) {
		blockArray[i] = Block();
	}

	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 64; j++) {
			if (map[i].at(j) == '1') {
				if (GameState::getGameState() == 4) {
					blockArray[count] = Block(j * 64, ((11 - i) * 64), "Assets/Art/SpaceshipyGroundBlock.png", 1);
				} else {
					blockArray[count] = Block(j * 64, ((11 - i) * 64), "Assets/Art/Sand.png", 1);
				}
				count++;
				cout << "1";
			}
			else if (map[i].at(j) == '2') {
				blockArray[count] = Block(j * 64, ((11 - i) * 64), "Assets/Art/spikes.png", 2);
				count++;
				cout << "2";
			}
			else if (map[i].at(j) == '3') {
				blockArray[count] = Block(j * 64, ((11 - i) * 64), "Assets/Art/Teleporter.png", 3);
				count++;
				cout << "3";
			}
			else {
				cout << "0";
			}
		}
		cout << endl;
	}
	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 64; j++) {
			if (map[i].at(j) == '4') {
				basicEnemyArray[basicEnemyCount] = BasicEnemy(j * 64, ((11 - i) * 64), this->blockArray, this->projectileArray);
				basicEnemyCount++;
				cout << "4";
			}
			else {
				cout << "0";
			}
		}
		cout << endl;
	}
	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 64; j++) {
			if (map[i].at(j) == '5') {
				chaseEnemyArray[chaseEnemyCount] = ChaseEnemy(j * 64, ((11 - i) * 64), this->blockArray, this->projectileArray);
				chaseEnemyCount++;
				cout << "5";
			}
			else {
				cout << "0";
			}
		}
		cout << endl;
	}
	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 64; j++) {
			if (map[i].at(j) == '6') {
				turretEnemyArray[turretEnemyCount] = TurretEnemy(j * 64, ((11 - i) * 64), this->blockArray, this->projectileArray);
				turretEnemyCount++;
				cout << "6";
			}
			else {
				cout << "0";
			}
		}
		cout << endl;
	}
	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 64; j++) {
			if (map[i].at(j) == '7') {
				bigBoss = BigBoss(j * 64, ((11 - i) * 64), this->blockArray);
				cout << "7";
			}
			else {
				cout << "0";
			}
		}
		cout << endl;
	}
}
