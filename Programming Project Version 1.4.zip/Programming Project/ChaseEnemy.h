#ifndef GAME_CHASEENEMY
#define GAME_CHASEENEMY

#include <cmath>
#include "Engine\Graphics\Sprite.h"
#include "Engine\Engine.h"
//#include "Player.h"
#include "Map.h"

class ChaseEnemy {

public:
	void Update(bool chasePlayer, float playerXPos);
	void Render();

	ChaseEnemy();
	ChaseEnemy(float _xPos, float _yPos, std::array<Block, 768> blockArray);

	float getXPos();
	float getYPos();
	int getHeight();
	int getWidth();
	int getAttackDamage();
	int getHealth();
	void setHealth(int _health);

private:
	Sprite chaseEnemySprite;
	std::array<Block, 768> blockArray;
	bool hasJump;
	float currentXPos;
	float currentYPos;
	float initialXPos;
	float initialYPos;
	float xVel;
	float yVel;
	int health;
	int attackDamage;
	void ChasePlayer(float playerXPos);
	void Patrol();
	void Jump();
	void checkCollisions();
};

#endif
