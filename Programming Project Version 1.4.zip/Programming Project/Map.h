#pragma once
#include <fstream>
#include <iostream>
#include <string>
#include <array>
#include "Engine\Graphics\Sprite.h"
#include "Block.h"

class Map {
public:
	Map(std::string mapFile);
	Map();
	void Render();
	void Update();
	void LoadMap(std::string mapFile);
	std::array<Block, 768> blockArray;
private:


	std::string mapString;
	std::ifstream input;
	std::array<std::string, 12> map;
	Sprite sprite;
	int count;
};