#include <iostream>
#include "Engine\Engine.h"
#include "Engine\Graphics\Sprite.h"
#include "Engine\Input\Mouse.h"
#include "Engine\Input\Keyboard.h"
#include "Player.h"
#include "BasicEnemy.h"
#include "ChaseEnemy.h"
#include "TurretEnemy.h"
#include "BigBoss.h"
#include "Health.h"
#include "Block.h"
#include "Map.h"
#include "Projectile.h"
#include "GameState.h"

using namespace std;

/* FIXME
- Dying from a spike results in an infinite loop of reloading the first map. (check player class in the checkcollision method for the fix)
- Level 2 loads, but nothing is moving. (fixed by setting gameChangeStates to false after level method exits; Ex: line 325)
- Pressing escape key doesn't change the level
- What does Block do? (line 73)
*/
/* THINGS TO DO
- Adjust how far the player has to be from the enemy in order to get hit.
- Find a way to make it so that health does become negative. (use unsigned int?)
- Find a way to get rid of the monster object once that monster has 0 health.
- Figure out what the Update() method should do in the Sprite class.
- Figure out how to play sound.
- Figure out behaviors for boss.
*/

/* NOTES
- When a monster has 0 health, the program stops rendering it so it doesn't appear on screen. The object still exists
  but you just can't see it.
- The attack of the player should be based on direction? (The player doesn't do damage to the monster if it is
  away from it)
- Attacking the enemy doesn't always guarantee a hit even if the player is extremely close to the monster.
*/

/* ADDED 
- Health to player and monsters.
- getters for position for player and monsters.
- getters and setters for the health of player and monsters.
- Player and monster attacks (along with how much damage they do).
- An option to restart the game after the player had died.
- Stops rendering the monsters once they have 0 health (they still exist though, they're just invisible).
- Health display for the player. Hearts disappear every time player's health decreases by 1/3.
- Sword sprite gets rendered if the player successfully hits a monster.
- Gave monsters Gravity.
- Player has invulnerability for a while after each hit.
*/

void levelOne(Engine engine) {

	//engine.Init("Test");
	Map map = Map("Assets/Maps/map1.txt");
	map.LoadMap("Assets/Maps/map1.txt");
	Sprite secondSprite = Sprite("Assets/Art/scithersword.png", 0, 500);
	Player player = Player(50, 100, map.blockArray);
	BasicEnemy patrolEnemy = BasicEnemy(100, 100, map.blockArray);
	ChaseEnemy chaseEnemy = ChaseEnemy(750, 100, map.blockArray);
	TurretEnemy turretEnemy = TurretEnemy(1500, 500, map.blockArray);
	BigBoss boss = BigBoss(3500, 65, map.blockArray);			//Boss Enemy Initilization
	Health health1 = Health(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
	Health health2 = Health(player.getXPos() - 25, player.getHeight() + player.getYPos() - 5);
	Health health3 = Health(player.getXPos() - 5, player.getHeight() + player.getYPos() - 5);
	Projectile projectile;
	int invulnerable = 0;	//Invulnerable is how long the player stays invulnerable for.

	//Block block = Block(100, 100);

	secondSprite.SetScaleTo(1);


	while (true) {
		if (invulnerable != 0) {	//Decreases time of invulnerablility by 1 each time the while loop runs.
			invulnerable--;
		}
		engine.Update();
		if (abs(player.getXPos() - chaseEnemy.getXPos()) < 300) {
			chaseEnemy.Update(true, player.getXPos());	//ChaseEnemy chases the player
		}
		else {
			chaseEnemy.Update(false, player.getXPos());	//ChaseEnemy patrols and doesn't chase the player.
		}
		//If statement checks whether or not player damages patrolEnemy.
		if (abs(player.getXPos() - patrolEnemy.getXPos()) < 15 && abs(player.getYPos() - patrolEnemy.getYPos()) < 15 && (Keyboard::KeyDown(GLFW_KEY_K))) {
			patrolEnemy.setHealth(patrolEnemy.getHealth() - player.getAttackDamage());
		}
		//If statement checks whether or not player damages ChaseEnemy.
		if (abs(player.getXPos() - chaseEnemy.getXPos()) < 15 && abs(player.getYPos() - chaseEnemy.getYPos()) < 15 && (Keyboard::KeyDown(GLFW_KEY_K))) {
			chaseEnemy.setHealth(chaseEnemy.getHealth() - player.getAttackDamage());
			cout << "Hit! ChaseEnemy Health: " << chaseEnemy.getHealth() << endl;
		}
		//These if statements control the health displayed on the screen
		if (player.getHealth() >= 3) {
			health1.Update(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
			health2.Update(player.getXPos() - 25, player.getHeight() + player.getYPos() - 5);
			health3.Update(player.getXPos() - 5, player.getHeight() + player.getYPos() - 5);
		}
		else if ((player.getHealth() < 3) && (player.getHealth() >= 2)) {
			health1.Update(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
			health2.Update(player.getXPos() - 25, player.getHeight() + player.getYPos() - 5);
		}
		else if ((player.getHealth() < 2) && player.getInitialHealth() > 1) {
			health1.Update(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
		}
		else {
		}
		//For loop checks if any of the Player's projectiles hit an enemy.
		for (int i = 0; i < 5; i++) {
			if (abs(player.getProjectile(i).getXPos() - patrolEnemy.getXPos()) < 20 && abs(player.getProjectile(i).getYPos() - patrolEnemy.getYPos()) < 20) {
				patrolEnemy.setHealth(patrolEnemy.getHealth() - player.getAttackDamage());
				//cout << "Hit! PatrolEnemy Health: " << patrolEnemy.getHealth() << endl;
			}
			if (abs(player.getProjectile(i).getXPos() - chaseEnemy.getXPos()) < 20 && abs(player.getProjectile(i).getYPos() - chaseEnemy.getYPos()) < 20) {
				chaseEnemy.setHealth(chaseEnemy.getHealth() - player.getAttackDamage());
				//cout << "Hit! ChaseEnemy Health: " << chaseEnemy.getHealth() << endl;
			}
		}
		if (abs(turretEnemy.getProjectile(0).getXPos() - player.getXPos()) < 20 && abs(turretEnemy.getProjectile(0).getYPos() - player.getYPos()) < 20 && invulnerable == 0) {
			player.setHealth(player.getHealth() - turretEnemy.getAttackDamage());
			//cout << "Hit! PatrolEnemy Health: " << patrolEnemy.getHealth() << endl;
			invulnerable = 500;
		}

		//Sprite Updates
		invulnerable = player.Update(patrolEnemy, invulnerable, chaseEnemy, turretEnemy);
		patrolEnemy.Update();
		turretEnemy.Update(player.getXPos(), player.getYPos());
		boss.Update(player.getXPos(), player.getYPos());
		secondSprite.Update();
		//block.Update();
		projectile.Update();

		//Start of the Rendering of Objects/Sprites
		engine.BeginRender();
		if (player.getHealth() >= 3) {
			health1.Render();
			health2.Render();
			health3.Render();
		}
		else if ((player.getHealth() < 3) && (player.getHealth() >= 2)) {
			health1.Render();
			health2.Render();
		}
		else if ((player.getHealth() < 2) && player.getInitialHealth() >= 1) {
			health1.Render();
		}
		else {
		}
		if (!(patrolEnemy.getHealth() <= 0)) {	//Only renders patrol enemy if it has health;
			patrolEnemy.Render();
		}
		if (!(chaseEnemy.getHealth() <= 0)) {		//Only renders chase enemy if it has health;
			chaseEnemy.Render();
		}
		if (!(turretEnemy.getHealth() <= 0)) {
			turretEnemy.Render();
		}
		if (invulnerable % 5 == 0) {
			player.Render();
		}
		secondSprite.Render();
		boss.Render();
		projectile.Render();
		map.Render();

		engine.EndRender();
		//End of rendering
		if (player.getHealth() <= 0) {
			break;
		}
		if (GameState::changeStates) {
			GameState::setGameState(GameState::getGameState() + 1);
			break;
		}
		if (GameState::restartStates) {
			break;
		}
	}
	return;
}

void levelTwo(Engine engine) {
	//engine.Init("Test");
	Map map = Map("Assets/Maps/map2.txt");
	map.LoadMap("Assets/Maps/map2.txt");
	Sprite secondSprite = Sprite("Assets/Art/scithersword.png", 0, 500);
	Player player = Player(50, 100, map.blockArray);
	BasicEnemy patrolEnemy = BasicEnemy(100, 100, map.blockArray);
	ChaseEnemy chaseEnemy = ChaseEnemy(750, 100, map.blockArray);
	TurretEnemy turretEnemy = TurretEnemy(1500, 500, map.blockArray);
	BigBoss boss = BigBoss(3500, 65, map.blockArray);			//Boss Enemy Initilization
	Health health1 = Health(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
	Health health2 = Health(player.getXPos() - 25, player.getHeight() + player.getYPos() - 5);
	Health health3 = Health(player.getXPos() - 5, player.getHeight() + player.getYPos() - 5);
	Projectile projectile;
	int invulnerable = 0;	//Invulnerable is how long the player stays invulnerable for.

	//Block block = Block(100, 100);

	secondSprite.SetScaleTo(1);

	while (true) {
		if (invulnerable != 0) {	//Decreases time of invulnerablility by 1 each time the while loop runs.
			invulnerable--;
		}
		engine.Update();
		if (abs(player.getXPos() - chaseEnemy.getXPos()) < 300) {
			chaseEnemy.Update(true, player.getXPos());	//ChaseEnemy chases the player
		}
		else {
			chaseEnemy.Update(false, player.getXPos());	//ChaseEnemy patrols and doesn't chase the player.
		}
		//If statement checks whether or not player damages patrolEnemy.
		if (abs(player.getXPos() - patrolEnemy.getXPos()) < 15 && abs(player.getYPos() - patrolEnemy.getYPos()) < 15 && (Keyboard::KeyDown(GLFW_KEY_K))) {
			patrolEnemy.setHealth(patrolEnemy.getHealth() - player.getAttackDamage());
		}
		//If statement checks whether or not player damages ChaseEnemy.
		if (abs(player.getXPos() - chaseEnemy.getXPos()) < 15 && abs(player.getYPos() - chaseEnemy.getYPos()) < 15 && (Keyboard::KeyDown(GLFW_KEY_K))) {
			chaseEnemy.setHealth(chaseEnemy.getHealth() - player.getAttackDamage());
			cout << "Hit! ChaseEnemy Health: " << chaseEnemy.getHealth() << endl;
		}
		//These if statements control the health displayed on the screen
		if (player.getHealth() >= 3) {
			health1.Update(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
			health2.Update(player.getXPos() - 25, player.getHeight() + player.getYPos() - 5);
			health3.Update(player.getXPos() - 5, player.getHeight() + player.getYPos() - 5);
		}
		else if ((player.getHealth() < 3) && (player.getHealth() >= 2)) {
			health1.Update(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
			health2.Update(player.getXPos() - 25, player.getHeight() + player.getYPos() - 5);
		}
		else if ((player.getHealth() < 2) && player.getInitialHealth() > 1) {
			health1.Update(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
		}
		else {
		}
		//For loop checks if any of the Player's projectiles hit an enemy.
		for (int i = 0; i < 5; i++) {
			if (abs(player.getProjectile(i).getXPos() - patrolEnemy.getXPos()) < 20 && abs(player.getProjectile(i).getYPos() - patrolEnemy.getYPos()) < 20) {
				patrolEnemy.setHealth(patrolEnemy.getHealth() - player.getAttackDamage());
				//cout << "Hit! PatrolEnemy Health: " << patrolEnemy.getHealth() << endl;
			}
			if (abs(player.getProjectile(i).getXPos() - chaseEnemy.getXPos()) < 20 && abs(player.getProjectile(i).getYPos() - chaseEnemy.getYPos()) < 20) {
				chaseEnemy.setHealth(chaseEnemy.getHealth() - player.getAttackDamage());
				//cout << "Hit! ChaseEnemy Health: " << chaseEnemy.getHealth() << endl;
			}
		}
		if (abs(turretEnemy.getProjectile(0).getXPos() - player.getXPos()) < 20 && abs(turretEnemy.getProjectile(0).getYPos() - player.getYPos()) < 20 && invulnerable == 0) {
			player.setHealth(player.getHealth() - turretEnemy.getAttackDamage());
			//cout << "Hit! PatrolEnemy Health: " << patrolEnemy.getHealth() << endl;
			invulnerable = 500;
		}

		//Sprite Updates
		invulnerable = player.Update(patrolEnemy, invulnerable, chaseEnemy, turretEnemy);
		patrolEnemy.Update();
		turretEnemy.Update(player.getXPos(), player.getYPos());
		boss.Update(player.getXPos(), player.getYPos());
		secondSprite.Update();
		//block.Update();
		projectile.Update();

		//Start of the Rendering of Objects/Sprites
		engine.BeginRender();
		if (player.getHealth() >= 3) {
			health1.Render();
			health2.Render();
			health3.Render();
		}
		else if ((player.getHealth() < 3) && (player.getHealth() >= 2)) {
			health1.Render();
			health2.Render();
		}
		else if ((player.getHealth() < 2) && player.getInitialHealth() >= 1) {
			health1.Render();
		}
		else {
		}
		if (!(patrolEnemy.getHealth() <= 0)) {	//Only renders patrol enemy if it has health;
			patrolEnemy.Render();
		}
		if (!(chaseEnemy.getHealth() <= 0)) {		//Only renders chase enemy if it has health;
			chaseEnemy.Render();
		}
		if (!(turretEnemy.getHealth() <= 0)) {
			turretEnemy.Render();
		}
		if (invulnerable % 5 == 0) {
			player.Render();
		}
		secondSprite.Render();
		boss.Render();
		projectile.Render();
		map.Render();

		engine.EndRender();
		//End of rendering
		if (player.getHealth() <= 0) {
			break;
		}
		if (GameState::changeStates) {
			GameState::setGameState(GameState::getGameState() + 1);
			break;
		}
		if (GameState::restartStates) {
			break;
		}
	}
	return;
}

void levelThree(Engine engine) {
	//engine.Init("Test");
	Map map = Map("Assets/Maps/map3.txt");
	map.LoadMap("Assets/Maps/map3.txt");
	Sprite secondSprite = Sprite("Assets/Art/scithersword.png", 0, 500);
	Player player = Player(50, 100, map.blockArray);
	BasicEnemy patrolEnemy = BasicEnemy(100, 100, map.blockArray);
	ChaseEnemy chaseEnemy = ChaseEnemy(750, 100, map.blockArray);
	TurretEnemy turretEnemy = TurretEnemy(1500, 500, map.blockArray);
	BigBoss boss = BigBoss(3500, 65, map.blockArray);			//Boss Enemy Initilization
	Health health1 = Health(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
	Health health2 = Health(player.getXPos() - 25, player.getHeight() + player.getYPos() - 5);
	Health health3 = Health(player.getXPos() - 5, player.getHeight() + player.getYPos() - 5);
	Projectile projectile;
	int invulnerable = 0;	//Invulnerable is how long the player stays invulnerable for.

							//Block block = Block(100, 100);

	secondSprite.SetScaleTo(1);


	while (true) {
		if (invulnerable != 0) {	//Decreases time of invulnerablility by 1 each time the while loop runs.
			invulnerable--;
		}
		engine.Update();
		if (abs(player.getXPos() - chaseEnemy.getXPos()) < 300) {
			chaseEnemy.Update(true, player.getXPos());	//ChaseEnemy chases the player
		}
		else {
			chaseEnemy.Update(false, player.getXPos());	//ChaseEnemy patrols and doesn't chase the player.
		}
		//If statement checks whether or not player damages patrolEnemy.
		if (abs(player.getXPos() - patrolEnemy.getXPos()) < 15 && abs(player.getYPos() - patrolEnemy.getYPos()) < 15 && (Keyboard::KeyDown(GLFW_KEY_K))) {
			patrolEnemy.setHealth(patrolEnemy.getHealth() - player.getAttackDamage());
		}
		//If statement checks whether or not player damages ChaseEnemy.
		if (abs(player.getXPos() - chaseEnemy.getXPos()) < 15 && abs(player.getYPos() - chaseEnemy.getYPos()) < 15 && (Keyboard::KeyDown(GLFW_KEY_K))) {
			chaseEnemy.setHealth(chaseEnemy.getHealth() - player.getAttackDamage());
			cout << "Hit! ChaseEnemy Health: " << chaseEnemy.getHealth() << endl;
		}
		//These if statements control the health displayed on the screen
		if (player.getHealth() >= 3) {
			health1.Update(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
			health2.Update(player.getXPos() - 25, player.getHeight() + player.getYPos() - 5);
			health3.Update(player.getXPos() - 5, player.getHeight() + player.getYPos() - 5);
		}
		else if ((player.getHealth() < 3) && (player.getHealth() >= 2)) {
			health1.Update(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
			health2.Update(player.getXPos() - 25, player.getHeight() + player.getYPos() - 5);
		}
		else if ((player.getHealth() < 2) && player.getInitialHealth() > 1) {
			health1.Update(player.getXPos() - 45, player.getHeight() + player.getYPos() - 5);
		}
		else {
		}
		//For loop checks if any of the Player's projectiles hit an enemy.
		for (int i = 0; i < 5; i++) {
			if (abs(player.getProjectile(i).getXPos() - patrolEnemy.getXPos()) < 20 && abs(player.getProjectile(i).getYPos() - patrolEnemy.getYPos()) < 20) {
				patrolEnemy.setHealth(patrolEnemy.getHealth() - player.getAttackDamage());
				//cout << "Hit! PatrolEnemy Health: " << patrolEnemy.getHealth() << endl;
			}
			if (abs(player.getProjectile(i).getXPos() - chaseEnemy.getXPos()) < 20 && abs(player.getProjectile(i).getYPos() - chaseEnemy.getYPos()) < 20) {
				chaseEnemy.setHealth(chaseEnemy.getHealth() - player.getAttackDamage());
				//cout << "Hit! ChaseEnemy Health: " << chaseEnemy.getHealth() << endl;
			}
		}
		if (abs(turretEnemy.getProjectile(0).getXPos() - player.getXPos()) < 20 && abs(turretEnemy.getProjectile(0).getYPos() - player.getYPos()) < 20 && invulnerable == 0) {
			player.setHealth(player.getHealth() - turretEnemy.getAttackDamage());
			//cout << "Hit! PatrolEnemy Health: " << patrolEnemy.getHealth() << endl;
			invulnerable = 500;
		}

		//Sprite Updates
		invulnerable = player.Update(patrolEnemy, invulnerable, chaseEnemy, turretEnemy);
		patrolEnemy.Update();
		turretEnemy.Update(player.getXPos(), player.getYPos());
		boss.Update(player.getXPos(), player.getYPos());
		secondSprite.Update();
		//block.Update();
		projectile.Update();

		//Start of the Rendering of Objects/Sprites
		engine.BeginRender();
		if (player.getHealth() >= 3) {
			health1.Render();
			health2.Render();
			health3.Render();
		}
		else if ((player.getHealth() < 3) && (player.getHealth() >= 2)) {
			health1.Render();
			health2.Render();
		}
		else if ((player.getHealth() < 2) && player.getInitialHealth() >= 1) {
			health1.Render();
		}
		else {
		}
		if (!(patrolEnemy.getHealth() <= 0)) {	//Only renders patrol enemy if it has health;
			patrolEnemy.Render();
		}
		if (!(chaseEnemy.getHealth() <= 0)) {		//Only renders chase enemy if it has health;
			chaseEnemy.Render();
		}
		if (!(turretEnemy.getHealth() <= 0)) {
			turretEnemy.Render();
		}
		if (invulnerable % 5 == 0) {
			player.Render();
		}
		secondSprite.Render();
		boss.Render();
		projectile.Render();
		map.Render();

		engine.EndRender();
		//End of rendering
		if (player.getHealth() <= 0) {
			break;
		}
		if (GameState::changeStates) {
			GameState::setGameState(GameState::getGameState() + 1);
			break;
		}
		if (GameState::restartStates) {
			break;
		}
	}
	return;
}


int main() {
	Engine engine;
	engine.Init("JOBASM");
	while (true) {
		while (true) {
			switch (GameState::getGameState()) {
			case 1:
				levelOne(engine);
				GameState::changeStates = false;	//Makes it so that you are able to play the next level and it doesn't automatically switch
				break;
			case 2:
				levelTwo(engine);
				GameState::changeStates = false;
				break;
			case 3:
				levelThree(engine);
				GameState::changeStates = false;
				break;
			default:
				break;
			}
		}
		string userInput;
		cout << "Game over! You have died!" << endl;
		cout << "Would you like to play again? (enter y or n)" << endl;
		cin >> userInput;
		if (userInput.compare("y") == 0) {
			continue;
		}
		else {
			break;
		}
	}
	return 0;
}